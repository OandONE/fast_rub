from ..types.errors import ServerRubikaError
from ..utils.utils import Utils
from pathlib import Path
from typing import Any, Literal, TYPE_CHECKING
try:
    from tqdm.asyncio import tqdm
except ImportError:
    tqdm = None
import os
import aiofiles
import asyncio
import httpx
import tempfile
import logging
import uuid

if TYPE_CHECKING:
    from ..core import Client


class Network:
    def __init__(
        self,
        token: str, # Delete in V7 (Dynamc getting from client. Live)
        client: "Client",
        logger: logging.Logger | None = None,
        max_retries: int = 3, # Delete in V7 (Dynamc getting from client. Live)
        user_agent: str | None = None,
        base_urls: list = [
            "https://botapi.rubika.ir/",
            # "https://messengerg2b1.iranlms.ir/"
        ], # Delete in V7 (Dynamc getting from client. Live)
        proxy: str | None = None,
        rate_limit: int = 20,
        ssl_verify: bool = True,
        max_retries_upload: int | None = None, # Delete in V7 (Dynamc getting from client. Live)
        max_retries_download: int | None = None, # Delete in V7 (Dynamc getting from client. Live)
        http2: bool = True,
    ):
        self.logger = logger or logging.getLogger("fast_rub.network")
        self.token = token
        self.user_agent = user_agent
        self.base_urls = base_urls
        self.proxy = proxy
        self.max_retries = max_retries

        self._client: httpx.AsyncClient | None = None
        self._client_lock = asyncio.Lock()

        self._rate_sem: asyncio.Semaphore | None = None
        self._queue: asyncio.Queue | None = None
        self._worker_task: asyncio.Task | None = None
        self._closed = False
        self._rate_limit = rate_limit

        self.ssl_verify = ssl_verify
        
        self.max_retries_upload = max_retries_upload or max_retries
        self.max_retries_download = max_retries_download or max_retries

        self._core_client = client

        self.http2 = http2

    # -------------------
    # Lifecycle: start / stop
    # -------------------
    async def start(
        self,
        *,
        start_worker: bool = True,
        limits: httpx.Limits | None = None
    ):
        asyncio.get_running_loop()

        if self._client_lock is None:
            self._client_lock = asyncio.Lock()
        if self._rate_sem is None:
            self._rate_sem = asyncio.Semaphore(self._rate_limit)
        if self._queue is None:
            self._queue = asyncio.Queue()

        self.limits = limits

        await self._create_client()

        if start_worker:
            await self.start_worker()

    async def _create_client(self):
        self._client = httpx.AsyncClient(**self._build_client_kwargs())
        self.logger.debug("HTTP client created")

    async def close(self):
        self._closed = True

        if self._worker_task:
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass

        if self._client and not self._client.is_closed:
            try:
                await self._client.aclose()
            except RuntimeError as e:
                if "Event loop is closed" not in str(e):
                    raise

    @staticmethod
    def _is_retryable_status(
        status_code: int
    ) -> bool:
        return status_code in (429, 500, 502, 503, 504)


    # -------------------
    # Worker queue
    # -------------------
    async def start_worker(self):
        if self._worker_task is None or self._worker_task.done():
            self._worker_task = asyncio.create_task(self._worker())
            self.logger.debug("Worker started")

    def _build_client_kwargs(self) -> dict:
        kwargs = {
            "timeout": httpx.Timeout(connect=10.0, read=30.0, write=10.0, pool=10.0),
            "limits": httpx.Limits(
                max_connections=100,
                max_keepalive_connections=100,
                keepalive_expiry=60.0
            ) if not self.limits else self.limits,
            "http1": True,
            "http2": self.http2,
            "verify": self.ssl_verify,
            "headers": {
                "Content-Type": "application/json"
            }
        }

        if self.user_agent:
            kwargs["headers"]["User-Agent"] = self.user_agent

        if self.proxy:
            try:
                httpx.AsyncClient(proxy=self.proxy)
                kwargs["proxies"] = self.proxy
            except TypeError:
                kwargs["proxy"] = self.proxy

        return kwargs


    async def _worker(self):
        if self._queue is None:
            self.logger.warning("Worker started but queue is None.")
            return

        while not self._closed:
            try:
                url, method, data_, headers, overrides, fut = await self._queue.get()
            except asyncio.CancelledError:
                break
            try:
                res = await self._do_request(url, method, data_, headers, **overrides)
                if not fut.done():
                    fut.set_result(res)
            except Exception as e:
                if not fut.done():
                    fut.set_exception(e)
            finally:
                try:
                    self._queue.task_done()
                except Exception:
                    pass

    # -------------------
    # Public request
    # -------------------
    async def request(
        self,
        url: str,
        data_: dict[str, Any] | list[Any] | None = None,
        type_send: Literal["POST", "GET", "HEAD"] = "POST",
        *,
        max_retries: int | None = None,
        timeout: float | None = None
    ) -> httpx.Response:
        if self._closed:
            raise RuntimeError("Network is closed")

        overrides = {
            "max_retries": max_retries or self._core_client.max_retries,
            "timeout": timeout or 30.0
        }

        return await self._do_request(url, type_send, data_, None, **overrides)

    # -------------------
    # Internal request with retry
    # -------------------
    async def _ensure_client(self):
        if self._client_lock is None:
            self._client_lock = asyncio.Lock()
        if self._rate_sem is None:
            self._rate_sem = asyncio.Semaphore(self._rate_limit)
        if self._queue is None:
            self._queue = asyncio.Queue()

        if self._client is None or (hasattr(self._client, "is_closed") and self._client.is_closed):
            async with self._client_lock:
                if self._client is None or (hasattr(self._client, "is_closed") and self._client.is_closed):
                    await self._create_client()

    async def _do_request(
        self,
        url: str,
        method: str,
        data_: dict | list | None,
        headers: dict[str, str] | None,
        *,
        max_retries: int,
        timeout: float
    ) -> httpx.Response:

        last_exception = None
        headers = headers.copy() if headers else {"Content-Type": "application/json"}
        if self.user_agent:
            headers["User-Agent"] = self.user_agent

        await self._ensure_client()

        for attempt in range(1, max_retries + 1):
            try:
                if self._rate_sem is None:
                    self._rate_sem = asyncio.Semaphore(self._rate_limit)

                async with self._rate_sem:
                    if method == "POST":
                        resp = await self._client.post(url, json=data_, headers=headers, timeout=timeout) # pyright: ignore[reportOptionalMemberAccess]
                    elif method == "GET":
                        resp = await self._client.get(url, headers=headers, timeout=timeout) # pyright: ignore[reportOptionalMemberAccess]
                    elif method == "HEAD":
                        resp = await self._client.head(url, headers=headers, timeout=timeout) # pyright: ignore[reportOptionalMemberAccess]
                    else:
                        raise ValueError(f"Invalid method: {method}")
                
                if self._is_retryable_status(
                    resp.status_code
                ):
                    if attempt < max_retries:
                        wait_time = 2 ** (attempt - 1)
                        self.logger.warning(f"Retry {attempt}/{max_retries} for status {resp.status_code}")
                        await asyncio.sleep(wait_time)
                        continue

                resp.raise_for_status()
                return resp

            except (httpx.ReadError, httpx.ConnectError, httpx.TimeoutException) as e:
                if not self._core_client.config.retry_on_timeout:
                    raise
                last_exception = e
                wait_time = attempt * 1.5
                self.logger.warning(f"Request failed attempt {attempt}/{max_retries}: {e}. Retrying in {wait_time}s...")

                if self._client_lock is None:
                    self._client_lock = asyncio.Lock()

                async with self._client_lock:
                    if self._client:
                        try:
                            await self._client.aclose()
                        except RuntimeError as re:
                            if "Event loop is closed" in str(re):
                                self.logger.debug("Event loop closed while closing client (during retry) - ignoring.")
                            else:
                                self.logger.exception("RuntimeError when closing client (during retry)")
                        except Exception:
                            pass
                        self._client = None

                try:
                    await self._ensure_client()
                except Exception as e2:
                    self.logger.exception(f"Failed to recreate client: {e2}")
                    raise e2

                await asyncio.sleep(wait_time)

            except Exception as e:
                self.logger.error(f"Unexpected error during request: {e}")
                raise e

        self.logger.error(f"All {max_retries} attempts failed for {url}")
        raise last_exception or RuntimeError("Unknown error in request")

    # -------------------
    # Rubika high-level
    # -------------------
    async def send_request(
        self,
        method: str,
        data: dict[str, Any] | None = None
    ) -> dict:
        self.logger.debug(f"method {method}")
        last_exception = None
        for base_url in self._core_client.base_urls:
            self.logger.debug(f"Base Url » {base_url}")
            url = f"{base_url}v3/{self._core_client.token}/{method}"
            try:
                if data:
                    if (
                        self._core_client.default_disable_notification is not None and
                        "disable_notification" in data and
                        data["disable_notification"] is None
                    ):
                        data["disable_notification"] = self._core_client.default_disable_notification
                    data = Utils.clean_dict(data)
                response = await self.request(url, data, "POST")
            except Exception as e:
                last_exception = e
                continue
            try:
                result = response.json()
            except:
                self.logger.error("Error Converting Response To JSON")
                raise ServerRubikaError("Error Converting Response To JSON")

            if not Utils.check_data(result):
                self.logger.error(f"Server Response Error: {result}")
                raise ServerRubikaError(result)

            return result["data"]
        raise last_exception or httpx.ConnectError("All Base Urls Sending Requests and Can't Get Response .")

    async def download(
        self,
        url: str,
        path: str = "file",
        show_progress: bool = False,
        max_retries: int | None = None
    ) -> bool:
        retries = max_retries if max_retries is not None else (
            self._core_client.max_retries_download if self._core_client.max_retries_download else self.max_retries_download
        )
        last_exception = None
        
        for attempt in range(1, retries + 1):
            try:
                await self._ensure_client()

                dir_path = os.path.dirname(path)
                if dir_path:
                    os.makedirs(dir_path, exist_ok=True)

                if self._rate_sem is None:
                    self._rate_sem = asyncio.Semaphore(self._rate_limit)

                async with self._rate_sem:
                    async with self._client.stream("GET", url) as response:  # pyright: ignore[reportOptionalMemberAccess]
                        response.raise_for_status()
                        total = int(response.headers.get("content-length", 0))
                        if show_progress and total:
                            if tqdm is None:
                                print("The tqdm library is not installed! for install: 'pip install fastrub[tqdm]' or 'pip install tqdm'")
                                pbar = None
                            else:
                                pbar = tqdm(total=total, unit="B", unit_scale=True, desc="Downloading")
                        else:
                            pbar = None
                        async with aiofiles.open(path, 'wb') as file:
                            async for chunk in response.aiter_bytes():
                                await file.write(chunk)
                                if pbar:
                                    pbar.update(len(chunk))
                        if pbar:
                            pbar.close()
                return True
                
            except (httpx.HTTPError, OSError) as e:
                last_exception = e
                if attempt < retries:
                    wait_time = 2 ** (attempt - 1)
                    self.logger.warning(f"Download failed attempt {attempt}/{retries}: {e}. Retrying in {wait_time}s...")
                    await asyncio.sleep(wait_time)
                    continue
                self.logger.error(f"Download failed after {retries} attempts: {e}")
                return False
            
            except Exception as e:
                self.logger.error(f"Download failed: {e}")
                return False
        
        return False

    async def upload(
        self,
        url: str,
        file_path: str | Path | bytes,
        file_name: str,
        show_progress: bool = False,
        chunk_size: int = 1024 * 1024, # 1 MB
        max_retries: int | None = None,
    ) -> dict[str, Any]:
        self.logger.info("در حال آپلود فایل (httpx async stream)...")
        await self._ensure_client()
        
        is_temp = False
        
        if isinstance(file_path, (bytes, bytearray)):
            tmp = tempfile.NamedTemporaryFile(delete=False)
            tmp.write(file_path)
            tmp.close()
            file_path = tmp.name
            is_temp = True
        
        try:
            total_size = os.path.getsize(file_path)
            
            boundary = uuid.uuid4().hex
            header = (
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="file"; filename="{file_name}"\r\n'
                f"Content-Type: application/octet-stream\r\n"
                f"\r\n"
            ).encode()
            footer = f"\r\n--{boundary}--\r\n".encode()
            content_length = len(header) + total_size + len(footer)
            
            last_exception = None
            retries = max_retries if max_retries is not None else (
                self._core_client.max_retries_upload if self._core_client.max_retries_upload else self.max_retries_upload
            )
            for attempt in range(1, retries + 1):
                try:
                    async def body_stream():
                        yield header
                        
                        if show_progress:
                            if tqdm is None:
                                print("The tqdm library is not installed! for install: 'pip install fastrub[tqdm]' or 'pip install tqdm'")
                                pbar = None
                            else:
                                pbar = tqdm(total=total_size, unit="B", unit_scale=True, desc="Uploading")
                        else:
                            pbar = None
                        
                        async with aiofiles.open(file_path, "rb") as f:
                            while True:
                                chunk = await f.read(chunk_size)
                                if not chunk:
                                    break
                                if pbar:
                                    pbar.update(len(chunk))
                                yield chunk
                        
                        if pbar:
                            pbar.close()
                        
                        yield footer
                    
                    response = await self._client.post( # type: ignore
                        url,
                        content=body_stream(),
                        headers={
                            "Content-Type": f"multipart/form-data; boundary={boundary}",
                            "Content-Length": str(content_length),
                        },
                        timeout=None
                    )
                    
                    if response.status_code == 200:
                        result = response.json()
                        self.logger.info("آپلود با موفقیت انجام شد")
                        return result["data"]
                    
                    if self._is_retryable_status(response.status_code):
                        if attempt < self.max_retries:
                            wait_time = 2 ** (attempt - 1)
                            self.logger.warning(f"خطای {response.status_code} - تلاش {attempt}/{self.max_retries}")
                            await asyncio.sleep(wait_time)
                            continue
                    
                    raise ServerRubikaError({
                        "status": "ERROR",
                        "detail": response.text
                    })
                    
                except (httpx.HTTPError, OSError) as e:
                    last_exception = e
                    if attempt < self._core_client.max_retries:
                        wait_time = 2 ** (attempt - 1)
                        self.logger.warning(f"خطای شبکه - تلاش {attempt}/{self._core_client.max_retries}")
                        await asyncio.sleep(wait_time)
                        continue
                    raise
            
            raise last_exception or RuntimeError("All upload retries failed")
        
        finally:
            if is_temp:
                os.remove(file_path)
