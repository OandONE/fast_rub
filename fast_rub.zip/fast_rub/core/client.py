import asyncio
import logging
import time
import os
import sys
import json
import hashlib
from functools import wraps
from pathlib import Path
from collections import deque
from typing import Any, Literal, TYPE_CHECKING
from collections.abc import Callable
from traceback import format_exc

import httpx
import aiofiles

from .async_sync import wrap_all_async_methods
from .middleware import MiddlewareManager
from .plugins import PluginManager
from .webhook_server import WebhookServer
from .background import BackgroundManager
from .hotreload import HotReload
from .helpers import _send_helper
from .signals import SignalManager
from .stats import StatsTracker
from .scheduler import Scheduler
from .config import BotConfig
from .dashboard import Dashboard
from .admin import AdminPanel
from .mock import MockNetwork, MockSession
from ..button import KeyPad
from ..utils.filters import Filter
from ..utils.inline_filters import InlineFilter
from ..network.network import Network
from ..types import Update, UpdateButton, msg_update
from ..types.errors import PollInvalid
from ..types.props import props
from ..types.models import Bot as BotModel, Chat as ChatModel
from ..types import WebhookConfig, AutoFailoverConfig
from ..utils.colors import Colors
from ..utils.logger import logging, set_log_callback, setup_logging
from ..utils.utils import Utils
from ..utils.text_parser import TextParser
from ..utils import WaitManager
from ..utils import Cache
from ..utils import SnapshotManager
from ..utils import TemplateEngine
from ..db.session import Session
from ..db.message_keeper import MessageKeeper
from ..pyrubi import Client as PyrubiClient
if TYPE_CHECKING:
    from .conversation import Conversation

class Client:
    """
    Client is the main interface of fast_rub for interacting with the Rubika Bot API.

    کلاس Client هستهٔ اصلی کتابخانه fast_rub است و تمام ارتباطات با Bot API روبیکا
    از طریق این کلاس انجام می‌شود.

    مسئولیت‌های اصلی:
    - مدیریت سشن، توکن و تنظیمات اولیه ربات
    - ارسال پیام، فایل، رسانه، نظرسنجی و سایر انواع محتوا
    - دریافت آپدیت‌ها (پیام، دکمه)
    - مدیریت هندلرها و توزیع آپدیت‌ها
    - کنترل لاگ‌ها، تایم‌اوت، پراکسی و retry

    این کلاس هم به صورت async و هم sync قابل استفاده است.
    بیشتر متدها به صورت async پیاده‌سازی شده‌اند اما با استفاده از

    مدل دریافت آپدیت‌ها:
    - on_message():
        دریافت پیام‌های جدید با polling
    - on_message_updates():
        دریافت پیام‌ها از طریق fast_rub webhook
    - on_button():
        دریافت کلیک‌های دکمه (Inline Keyboard)

    فعال یا غیرفعال بودن هر نوع آپدیت با فلگ‌های داخلی مشخص می‌شود
    و در صورت ثبت نشدن هندلر مناسب، اجرای کلاینت متوقف خواهد شد.

    Parameters
    ----------
    name_session : str
        نام سشن برای ذخیره تنظیمات و توکن

    token : Optional[str]
        توکن ربات (در صورت نبود، از فایل سشن خوانده می‌شود)

    user_agent : Optional[str]
        مقدار User-Agent برای درخواست‌های HTTP

    time_out : float = 60.0
        تایم‌اوت درخواست‌ها (بر حسب ثانیه)

    display_welcome : bool = False
        نمایش پیام خوش‌آمدگویی هنگام شروع

    save_logs : Optional[bool]
        ذخیره لاگ‌ها در فایل

    view_logs : Optional[bool]
        نمایش لاگ‌ها در کنسول

    proxy : Optional[str]
        پراکسی برای ارتباطات شبکه

    main_parse_mode : Literal['Markdown', 'HTML', 'Null', None] = "Null"
        پارس مود پیش‌فرض پیام‌ها
        اگر مقدار 'Null' باشد، پارس مود هر متد به صورت جداگانه اعمال می‌شود

    base_urls : list = [
            "https://botapi.rubika.ir/", # "https://messengerg2b1.iranlms.ir/"
        ]
        لیست آدرس های اصلی برای ارسال درخواست

    max_retries : int = 5
        حداکثر تعداد تلاش مجدد در خطاهای شبکه

    show_progress: Optional[bool]
        نمایش لاگ های ارسال انواع فایل 
    
    keeper_messages_ram: int = 5_000
        تعداد پیام ها برای ذخیره شدن در لیست از سمت پروسس های گرفتن پیام ها برای متود گت مسیج در رم
    
    keeper_messages_db: int = 0
        تعداد پیام ها برای ذخیره شدن در لیست از سمت پروسس های گرفتن پیام ها برای متود گت مسیج در دیتابیس
    
    logger: logging.Logger | None = None
        لاگر اختصاصی برای لاگ های فست روب
    
    offset_id: Optional[str] = None
        آفست آیدی برای گرفتن پیام های پولینگ
    
    save_offset_id: bool = True
        ذخیره شدن آفست آیدی در دیتابیس
    
    run_start: bool = False
        اجرا کردن متود start با asyncio.run - توصیه می شود متود start را در محیط کد خود اجرا کنید و این مقدار با نادرست 
    
    wait_manager: Optional[WaitManager] = None
        مدیریت ایستادن بین ارسال درخواست ها
    
    defult_wait: Optional[float] = None
        مقدار پیشفرض ایستادن بین درخواست ها
    
    webhook: Optional[WebhookConfig] = None
        تنظیمات وبهوک

    auto_failover: AutoFailoverConfig | None = None
        Failover timing settings; enable handlers with @bot.failover_on_message(). / تنظیمات زمانی؛ فعال‌سازی با دکوراتور اختصاصی.
    
    poll_interval: float = 0.0
        زمان ایستادن بین گرفتن پیام ها
    
    ssl_verify: bool = True
        احراز هویت SSL
    
    cache: Cache | None = None
        کلاس کش برای مدیریت کش
    
    cache_max_size: int | None
        حداکثر مقدار کش

    cache_ttl: float | None
        ttl کش
    
    max_retries_upload: int | None
        حداکثر تلاش برای آپلود فایل
    
    max_retries_download: int | None
        حداکثر تلاش برای دانلود فایل
    
    config: BotConfig | None
        کانفیگ تنظیمات اختصاصی ربات
    
    enable_stats: bool = False
        آمار در پنل HTML
    
    stats_db_path: str | None = None
        دیتابیس آمار

    dry_run: bool = False
        حالت شبیه‌سازی (Dry Run) - ربات بدون توکن واقعی و بدون اینترنت اجرا می‌شود.
        آپدیت‌ها را با bot.mock.receive_text(...) شبیه‌سازی کنید؛
        همهٔ ارسال‌های ربات در bot.mock.sent و همهٔ درخواست‌ها در bot.mock.requests ثبت می‌شوند.
    
    http2: bool = True
        فعال شدن http2 برای ارسال درخواست ها
    
    network_limits: httpx.Limits | None = None
        لیمیت نتورک برای ارسال درخواست ها
        در صورت تنظیم نشدن به صورت پیشفرض بهترین انتخاب برای ربات های بزرگ تنظیم میشود
    
    default_disable_notification: bool | None = None
        غیرفعال کردن اعلان به صورت پیشفرض
    
    network_rate_limit: int = 20
        محدودیت تعداد تسک همزمان در شبکه(نتورک)
    """
    # ═══════════════════════════════════
    # region 🚀 Start & Stop | شروع و توقف
    # ═══════════════════════════════════
    def __init__(
        self,
        name_session: str,
        token: str | None = None,
        user_agent: str | None = None,
        time_out: float = 60.0,
        display_welcome: bool = False,
        save_logs: bool | None = None,
        view_logs: bool | None = None,
        proxy: str | None = None,
        main_parse_mode: Literal['Markdown', 'HTML', "Null", None] = "Null",
        base_urls: list = [
            "https://botapi.rubika.ir/",
            # "https://messengerg2b1.iranlms.ir/"
        ],
        max_retries: int = 5,
        show_progress: bool | None = None,
        keeper_messages_ram: int = 5_000,
        keeper_messages_db: int = 0,
        logger: logging.Logger | None = None,
        offset_id: str | None = None,
        save_offset_id: bool = True,
        run_start: bool = False, # Remove in V7
        wait_manager: WaitManager | None = None,
        defult_wait: float | None = None,
        webhook: WebhookConfig | None = None,
        poll_interval: float = 0.0,
        ssl_verify: bool = True,
        cache: Cache | None = None,
        cache_max_size: int | None = None,
        cache_ttl: float | None = None,
        max_retries_upload: int | None = None,
        max_retries_download: int | None = None,
        config: BotConfig | None = None,
        enable_stats: bool = False,
        stats_db_path: str | None = None,
        dry_run: bool = False,
        http2: bool = True,
        network_limits: httpx.Limits | None = None,
        default_disable_notification: bool | None = None,
        auto_failover: AutoFailoverConfig | None = None,
        network_rate_limit: int = 20,
    ):
        """Create a client / ساخت کلاینت ربات"""
        self.name_session = name_session
        self.token = token # pyright: ignore[reportAttributeAccessIssue]
        self.save_logs = save_logs
        self.view_logs = view_logs
        self.display_welcome = display_welcome
        self.time_out = time_out
        self.user_agent = user_agent
        self.proxy = proxy
        self.show_progress = show_progress
        self.main_parse_mode: Literal['Markdown', 'HTML', 'Null', None] = main_parse_mode
        self.max_retries = max_retries
        self.max_retries_upload = max_retries_upload
        self.max_retries_download = max_retries_download
        self.keeper_messages_ram = keeper_messages_ram
        # self.urls: list[str] = base_urls
        self.base_urls: list[str] = base_urls
        self.offset_id = offset_id
        self.save_offset_id = save_offset_id
        self.keeper_messages_db = keeper_messages_db
        self.wait_manager = wait_manager
        self.defult_wait = defult_wait
        from .conversation import ConversationManager
        self._conversation_manager = ConversationManager()
        self._cache = cache
        self._cache_max_size = cache_max_size
        self._cache_ttl = cache_ttl
        self.webhook = webhook
        self.auto_failover = auto_failover
        self._auto_failover_defaults = {
            "check_interval": 5.0,
            "failure_timeout": 15.0,
            "recovery_successes": 5,
        }
        self._auto_failover_pipeline_keys: set[str] = set()
        self._auto_failover_pipeline_order = deque()
        self._auto_failover_conversation_keys: set[str] = set()
        self._auto_failover_conversation_order = deque()
        self._auto_failover_polling_failure_since: float | None = None
        self.poll_interval = poll_interval
        self.ssl_verify = ssl_verify
        self.state = {}
        self.template = TemplateEngine(self)
        self._on_ready_handlers = []
        self._on_start_handlers = []
        self._on_error_handlers = []
        self._on_run_handlers = []
        self._on_live_handlers = []
        self._on_shutdown_handlers = []
        self._before_run_handlers = []
        self._after_run_handlers = []
        self._message_handlers_polling = []
        self._message_handlers_failover = []
        self._button_handlers = []
        self._button_handlers_url = []
        self._webhook_handlers_url = []
        self._edit_handlers = []
        self._edit_handlers_ = []
        self._message_handlers_webhook = []
        self._before_send_handlers = []
        self._after_send_handlers = []
        self._loaded_plugins = []
        self._log_handlers = []
        self._is_started = False
        self.config = config or BotConfig()
        self.enable_stats = enable_stats
        self.stats_db_path = stats_db_path
        self.stats: StatsTracker | None = None
        self._dashboard: "Dashboard | None" = None
        self._dashboard_task: asyncio.Task | None = None
        self._admin: AdminPanel | None = None
        self._admin_task: asyncio.Task | None = None
        self.dry_run = dry_run
        self.http2 = http2
        self.network_limits = network_limits
        self._pending_tasks: set[asyncio.Task] = set()
        self.default_disable_notification = default_disable_notification
        self.network_rate_limit = network_rate_limit
        if logger:
            self.logger = logger
        else:
            self.logger = logging.getLogger("fast_rub")
        self.mock: MockNetwork = MockNetwork(client=self, logger=self.logger)
        if run_start: # Remove in V7
            asyncio.run(self.start())

    def _resolve_auto_failover_config(
        self,
        decorator_config: AutoFailoverConfig | None = None,
    ) -> dict[str, Any]:
        """Merge failover options / تنظیمات Failover را ادغام می‌کند"""
        resolved = dict(self._auto_failover_defaults)
        # Client options provide defaults; decorator options override them.
        for config in (self.auto_failover, decorator_config):
            if config is None:
                continue
            if not isinstance(config, AutoFailoverConfig):
                raise TypeError("auto_failover باید از نوع AutoFailoverConfig یا None باشد")
            for name in resolved:
                value = getattr(config, name)
                if value is not None:
                    resolved[name] = value
        return resolved

    def _auto_failover_infos(self) -> list[dict[str, Any]]:
        """Return dedicated failover handlers / هندلرهای اختصاصی Failover را برمی‌گرداند"""
        return self._message_handlers_failover

    def _auto_failover_enabled(self) -> bool:
        """Check whether failover handlers exist / فعال بودن هندلرهای Failover را بررسی می‌کند"""
        return bool(self._message_handlers_failover)

    @staticmethod
    def _auto_failover_update_key(message: dict[str, Any]) -> str:
        """Build a stable event key / شناسه‌ای پایدار برای آپدیت می‌سازد"""
        # Normalize deletion names so Polling and Webhook identify the same event.
        normalized = dict(message)
        event_type = normalized.get("type", "")
        if event_type in ("RemoveMessage", "RemovedMessage"):
            event_type = "RemovedMessage"
        normalized["type"] = event_type
        payload = json.dumps(
            normalized,
            sort_keys=True,
            ensure_ascii=False,
            default=str,
            separators=(",", ":"),
        )
        digest = hashlib.sha256(payload.encode("utf-8", errors="replace")).hexdigest()
        return f"{event_type}:{digest}"

    @staticmethod
    def _remember_handler_update(handler_info: dict[str, Any], key: str) -> bool:
        """Reject duplicate deliveries / دریافت تکراری آپدیت را رد می‌کند"""
        seen = handler_info.setdefault("_auto_failover_seen", set())
        order = handler_info.setdefault("_auto_failover_seen_order", deque())
        if key in seen:
            return False
        seen.add(key)
        order.append(key)
        # Bound memory usage while retaining a useful recent deduplication window.
        while len(order) > 2048:
            seen.discard(order.popleft())
        return True

    def _remember_pipeline_update(self, key: str) -> bool:
        """Track updates already passed through the shared pipeline / عبور قبلی آپدیت از مسیر مشترک را ثبت می‌کند"""
        if key in self._auto_failover_pipeline_keys:
            return False
        self._auto_failover_pipeline_keys.add(key)
        self._auto_failover_pipeline_order.append(key)
        while len(self._auto_failover_pipeline_order) > 4096:
            self._auto_failover_pipeline_keys.discard(self._auto_failover_pipeline_order.popleft())
        return True

    def _auto_failover_check_interval(self) -> float:
        """Get the fastest configured monitor interval / کمترین فاصله بررسی را می‌گیرد"""
        values = [
            info["auto_failover_config"]["check_interval"]
            for info in self._auto_failover_infos()
        ]
        return min(values) if values else 5.0

    def _remember_conversation_consumed(self, key: str) -> None:
        """Remember updates consumed by Conversation / آپدیت مصرف‌شده توسط Conversation را ثبت می‌کند"""
        if key in self._auto_failover_conversation_keys:
            return
        self._auto_failover_conversation_keys.add(key)
        self._auto_failover_conversation_order.append(key)
        while len(self._auto_failover_conversation_order) > 4096:
            self._auto_failover_conversation_keys.discard(self._auto_failover_conversation_order.popleft())

    async def _dispatch_auto_failover_update(
        self,
        message: dict[str, Any],
        handler_infos: list[dict[str, Any]],
        source: str,
        normal_pipeline_ran: bool = False,
    ) -> bool:
        """Dispatch one update once / آپدیت را فقط یک‌بار توزیع می‌کند"""
        if not handler_infos:
            return False
        key = self._auto_failover_update_key(message)
        # Conversations take precedence over message callbacks on both transports.
        if key in self._auto_failover_conversation_keys:
            return True
        fresh_infos = []
        for info in handler_infos:
            if self._remember_handler_update(info, key):
                fresh_infos.append(info)
        if not fresh_infos:
            return False

        first_pipeline_delivery = self._remember_pipeline_update(key)
        deleted_type = message.get("type")
        if deleted_type not in ("RemoveMessage", "RemovedMessage"):
            deleted_type = "RemoveMessage" if source == "polling" else "RemovedMessage"
        consumed = await self._process_message_update(
            message=message,
            handler_infos=fresh_infos,
            deleted_message_type=deleted_type,
            handle_conversation=first_pipeline_delivery and not normal_pipeline_ran,
            store_message=first_pipeline_delivery and not normal_pipeline_ran,
        )
        if consumed:
            self._remember_conversation_consumed(key)
        return consumed

    async def _queue_or_dispatch_polling_update(self, message: dict[str, Any]) -> None:
        """Queue webhook-missing updates or dispatch polling fallback / آپدیت‌های مفقود وب‌هوک را صف یا با Polling ارسال می‌کند"""
        key = self._auto_failover_update_key(message)
        now = time.monotonic()
        normal_pipeline_ran = bool(self._message_handlers_polling)

        for info in self._auto_failover_infos():
            if info.get("active_source") == "polling":
                await self._dispatch_auto_failover_update(
                    message, [info], "polling", normal_pipeline_ran=normal_pipeline_ran
                )
            elif key not in info.get("_auto_failover_seen", set()):
                # The timer is created only once; repeated polling batches must not reset it.
                info.setdefault("_auto_failover_pending", {}).setdefault(
                    key, (now, message, normal_pipeline_ran)
                )
        await self._flush_auto_failover_pending()

    async def _flush_auto_failover_pending(self) -> None:
        """Switch to Polling when Webhook misses an update / در صورت مفقودی آپدیت، به Polling سوییچ می‌کند"""
        now = time.monotonic()
        for info in self._auto_failover_infos():
            if info.get("active_source") != "webhook":
                continue
            pending = info.get("_auto_failover_pending", {})
            timeout = info["auto_failover_config"]["failure_timeout"]
            ready = [
                (key, created, message, normal_ran)
                for key, (created, message, normal_ran) in list(pending.items())
                if key not in info.get("_auto_failover_seen", set())
                and now - created >= timeout
            ]
            # Webhook may have delivered queued updates while we were waiting.
            for key in list(pending):
                if key in info.get("_auto_failover_seen", set()):
                    pending.pop(key, None)
            if not ready:
                continue

            info["active_source"] = "polling"
            info["_auto_failover_recovery_streak"] = 0
            self.logger.warning("Auto Failover: Webhook missed an update; switched to Polling.")
            # Deliver the entire pending queue after the switch to avoid dropping newer events.
            for key, (_created, message, normal_ran) in list(pending.items()):
                pending.pop(key, None)
                await self._dispatch_auto_failover_update(
                    message, [info], "polling", normal_pipeline_ran=normal_ran
                )

    def _on_polling_success(self) -> None:
        """Reset Polling failure timer / شمارنده خطای Polling را پاک می‌کند"""
        self._auto_failover_polling_failure_since = None

    def _on_polling_failure(self) -> None:
        """Return to Webhook if fallback Polling stays unavailable / هنگام خرابی طولانی Polling به وب‌هوک برمی‌گردد"""
        now = time.monotonic()
        if self._auto_failover_polling_failure_since is None:
            self._auto_failover_polling_failure_since = now
        elapsed = now - self._auto_failover_polling_failure_since
        for info in self._auto_failover_infos():
            if info.get("active_source") != "polling":
                continue
            if elapsed >= info["auto_failover_config"]["failure_timeout"]:
                info["active_source"] = "webhook"
                info["_auto_failover_recovery_streak"] = 0
                self.logger.warning("Auto Failover: Polling is unavailable; switched back to Webhook.")

    async def start(self):
        """Initialize Client runtime resources / آماده‌سازی منابع کلاینت"""
        self._is_started = True
        self._running = False
        # Rebuild these flags from registered handlers. Resetting them here made
        # handlers registered before run() disappear from run-time validation.
        failover_enabled = bool(self._message_handlers_failover)
        self._fetch_messages_webhook = bool(self._message_handlers_webhook or failover_enabled)
        self._fetch_messages_polling = bool(self._message_handlers_polling or failover_enabled)
        self._fetch_buttons = bool(self._button_handlers)
        self._fetch_edit = any(
            info.get("edited_messages") for info in
            (self._message_handlers_polling + self._message_handlers_webhook + self._message_handlers_failover)
        )
        self.next_offset_id_get_message = None
        self.geted_u = 0
        self.list_commands = []
        self.messages = deque(maxlen=self.keeper_messages_ram)
        self.messages_db = MessageKeeper(
            db_path=self.name_session,
            number_keeper=self.keeper_messages_db
        )
        self.signals = SignalManager(
            logger=self.logger
        )
        self.scheduler = Scheduler(self.logger)
        self.snapshots = SnapshotManager(self)
        if self.dry_run:
            # Try run - no session, database, valid token
            self.token = self.token or ("0" * 64)
            self.session = MockSession(
                token=self.token,
                user_agent=self.user_agent,
                time_out=self.time_out,
                display_welcome=self.display_welcome,
                view_logs=self.view_logs or False,
                save_logs=self.save_logs or False,
                offset_id=self.offset_id,
                save_offset_id=self.save_offset_id,
            )
            self.logger.info("حالت Dry Run فعال است - اتصال واقعی به سرور روبیکا وجود ندارد")
        else:
            self.session = await Session.open(
                name=self.name_session,
                token=self.token,
                user_agent=self.user_agent,
                time_out=self.time_out,
                display_welcome=self.display_welcome,
                view_logs=self.view_logs,
                save_logs=self.save_logs,
                offset_id=self.offset_id,
                save_offset_id=self.save_offset_id
            )
            await self.session.close()
        self.token: str = self.session.token
        self.time_out = self.session.time_out
        self.user_agent = self.session.user_agent
        try:
            self.log_to_file = self.session.save_logs
            self.log_to_console = self.session.view_logs
        except KeyError:
            pass
        if self.log_to_file is None:
            self.log_to_file = False
        if self.log_to_console is None:
            self.log_to_console = False
        setup_logging(
            log_to_console=self.log_to_console,
            log_to_file=self.log_to_file
        )
        self.exists_wait_manager = bool(self.wait_manager)
        self.main_url = self.base_urls[0]
        self.base_urls = Utils.format_url(self.base_urls)
        self.next_offset_id = self.session.offset_id
        self.save_offset_id = self.session.save_offset_id
        if self.dry_run:
            self.network = self.mock
        else:
            self.network = Network(
                token=self.token,
                client=self,
                logger=self.logger,
                max_retries=self.max_retries,
                user_agent=self.user_agent,
                proxy=self.proxy,
                base_urls=self.base_urls,
                ssl_verify=self.ssl_verify,
                max_retries_upload=self.max_retries_upload,
                max_retries_download=self.max_retries_download,
                http2=self.http2,
                rate_limit=self.network_rate_limit,
            )
            await self.network.start(
                start_worker=True,
                limits=self.network_limits
            )
        self._webhook_server = None
        if self.webhook:
            self._webhook_server = WebhookServer(client=self, config=self.webhook, logger=self.logger)
        self._middleware_manager = MiddlewareManager(self.logger)
        self._background = BackgroundManager(self.logger)
        if self._cache is not None:
            self.cache = self._cache
        elif self._cache_ttl or self._cache_max_size:
            self.cache = Cache(
                ttl=self._cache_ttl,
                max_size=self._cache_max_size
            )
        else:
            self.cache = None
        self._is_live = False
        if self.enable_stats:
            db_path = self.stats_db_path
            if db_path is None:
                db_path = f"messages_state-fastrub-{self.name_session}.db"
            self.stats = StatsTracker(db_path=db_path, logger=self.logger)
            self.stats.attach_client(self)
            await self.stats.start()
            self.logger.info(f"📊 Stats enabled (DB: {db_path})")
        def _log_callback(log_entry):
            for handler in self._log_handlers:
                try:
                    result = handler(log_entry)
                    if asyncio.iscoroutine(result):
                        asyncio.create_task(result)
                except Exception:
                    pass
        set_log_callback(_log_callback)
        await self._process_on_start()
        await self._process_on_ready()
        if self.display_welcome:
            Utils.print_time("Welcome To FastRub", color=Colors.GREEN)
        self.logger.info("سشن اماده است")

    async def _run_all(self):
        """Start configured receiver tasks / راه‌اندازی مسیرهای دریافت آپدیت"""
        tasks = []
        
        auto_failover_enabled = bool(self._message_handlers_failover)
        if auto_failover_enabled and self._webhook_server is None:
            raise ValueError("failover_on_message() requires webhook=WebhookConfig(...)")

        if self._webhook_server and (
            self._message_handlers_webhook or self._button_handlers or auto_failover_enabled
        ):
            tasks.append(self._webhook_server.start())

        if self._fetch_messages_polling and (self._message_handlers_polling or auto_failover_enabled):
            tasks.append(self._process_messages_polling())
        
        if not tasks:
            raise ValueError("No handlers registered. Use decorator first.")
        
        try:
            messages = await self.get_updates(limit=100)
            self.next_offset_id_get_message = messages["next_offset_id"]
        except KeyError:
            pass
        
        if tasks:
            await self._process_on_run()
        
        await asyncio.gather(*tasks, return_exceptions=True)

    async def run(
        self,
        poll_interval: float = 0.0,
        reload: bool = False
    ):
        """اجرای اصلی بات - فقط اگر هندلرهای مربوطه ثبت شده باشند"""

        if not reload and "--reload" in sys.argv:
            reload = True

        if reload and not os.environ.get("FASTRUB_RELOAD_CHILD"):
            script_path = str(Path(sys.argv[0]).resolve())
            self._hotreload = HotReload(self.logger)
            try:
                await self._hotreload.run_async(script_path)
            except KeyboardInterrupt:
                self.logger.info("Hot Reload با Ctrl+C متوقف شد")
            return

        try:
            if not self._is_started:
                await self.start()

            if not (
                self._fetch_messages_webhook
                or self._fetch_buttons
                or self._fetch_messages_polling
                or self._fetch_edit
            ):
                raise ValueError("No update types selected. Use decorator first.")

            has_failover_handlers = bool(self._message_handlers_failover)
            if (
                self._fetch_messages_webhook and not (self._message_handlers_webhook or has_failover_handlers)
            ) or (
                self._fetch_messages_polling and not (self._message_handlers_polling or has_failover_handlers)
            ):
                raise ValueError(
                    "Message handlers registered but no message callbacks defined."
                )

            if self._fetch_buttons and not self._button_handlers:
                raise ValueError(
                    "Button handlers registered but no button callbacks defined."
                )

            if self._fetch_edit and not (
                self._message_handlers_polling or self._message_handlers_webhook or self._message_handlers_failover
            ):
                raise ValueError(
                    "Edit handlers registered but no message callbacks defined."
                )

            if poll_interval != 0.0:
                self.poll_interval = poll_interval
            else:
                env_pi = os.environ.get("FASTRUB_POLL_INTERVAL")
                if env_pi:
                    try:
                        self.poll_interval = float(env_pi)
                        self.logger.info(
                            f"poll_interval از متغیر محیطی تنظیم شد: {self.poll_interval}"
                        )
                    except ValueError:
                        self.logger.warning(
                            f"مقدار نامعتبر FASTRUB_POLL_INTERVAL: {env_pi!r}"
                        )

            self._running = True

            await self._process_before_run()

            self.logger.info("ربات در حال دریافت پیام ها")
            if self.display_welcome:
                Utils.print_time("Start", color=Colors.BLUE)

            await self._run_all()

        except KeyboardInterrupt:
            self.logger.info("Ctrl+C received")
        finally:
            if self._is_started:
                await self._process_after_run()
                await self.close()


    run_sync = run

    async def close(
        self,
        type_stop: Literal["all", "running"] = "all"
    ):
        """خاموش کردن گرفتن آپدیت ها / off the getting updates"""
        self.logger.info("ربات متوقف شد !")
        self._running = False
        
        if self._dashboard_task is not None:
            self._dashboard_task.cancel()
            try:
                await self._dashboard_task
            except (asyncio.CancelledError, Exception):
                pass
            self._dashboard_task = None
            if self._dashboard:
                await self._dashboard.stop()

        if self._admin_task is not None:
            self._admin_task.cancel()
            try:
                await self._admin_task
            except (asyncio.CancelledError, Exception):
                pass
            self._admin_task = None
            if self._admin:
                try:
                    await self._admin.stop()
                except Exception:
                    pass
            self._admin = None

        if getattr(self, "stats", None) is not None:
            try:
                await self.stats.close() # pyright: ignore[reportOptionalMemberAccess]
            except Exception:
                pass
            self.stats = None
        for task in self._pending_tasks:
            task.cancel()
        if self._pending_tasks:
            await asyncio.gather(*self._pending_tasks, return_exceptions=True)
        self._pending_tasks.clear()
        if type_stop == "all":
            await self.network.close()
            del self.network
            del self.session
            del self.token
            del self.name_session
            del self.logger
            del self.base_urls
            del self.main_url
            await self._process_on_shutdown()

    async def stop(
        self
    ):
        """stop getting updates / متوقف شدن گرفتن آپدیت ها"""
        await self.close(type_stop="running")
    
    def __enter__(self):
        self.start() # type: ignore
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close() # type: ignore
    
    async def __aenter__(self):
        await self.start()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    @property
    def TOKEN(self):
        self.logger.warning("توکن دریافت شد")
        return self.token
    
    @TOKEN.setter
    def TOKEN(
        self,
        value: str
    ):
        self.token = value
        self.logger.info("توکن تغییر کرد")
    
    # endregion

    # ═══════════════════════════════════
    # region ⚙️ Internal Utils | متدهای داخلی
    # ═══════════════════════════════════

    
    async def _auto_delete(
        self,
        chat_id: str,
        message_id: str,
        time_sleep: float
    ) -> props:
        Utils.check_message_id_raise(message_id)
        Utils.check_id_raise(chat_id)
        await asyncio.sleep(time_sleep)
        result = await self.delete_message(
            chat_id=chat_id,
            message_id=message_id
        )
        
        if isinstance(result, props):
            return result
        return props(result)
    
    
    def _parse_mode_text(
        self,
        text: str,
        parse_mode: Literal["Markdown","HTML","Null",None] = "Markdown"
    ) -> tuple[list[dict[str, Any]], str]:
        """setting parse mode text / تنظیم پارس مود متن"""
        if self.main_parse_mode != "Null":
            parse_mode = self.main_parse_mode
        if self.config.strip_text:
            text = Utils.trim_text(text)
        if self.config.optimize_text:
            text = " ".join(text.split())
        if self.config.max_text_length and len(text) > self.config.max_text_length:
            if self.config.compress_long_text:
                text = text[:self.config.max_text_length - 3] + "..."
            else:
                text = text[:self.config.max_text_length]
        if parse_mode == "Markdown":
            data = TextParser.markdown(text)
            return data
        elif parse_mode == "HTML":
            data = TextParser.html(text)
            return data
        return [], text

    async def _wait(
        self,
        wait_send: float | None = None
    ) -> float | None:
        return wait_send or (
            await self.wait_manager.get_time() if self.wait_manager else None
        ) or self.defult_wait

    async def _manage_auto_delete(
        self,
        data: dict,
        auto_delete: int | None = None
    ) -> None:
        if auto_delete:
            message_id = data["message_id"]
            chat_id = data["chat_id"]
            await self.auto_delete(
                chat_id=chat_id,
                message_id=message_id,
                time_sleep=auto_delete,
                separate_task=True
            )
    
    async def _auto_edit(
        self,
        chat_id: str,
        message_id: str,
        text: str,
        auto_edit: int,
        inline_keypad: list | KeyPad | None = None,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        meta_data: list | None = None,
        context: dict | None = None,
        auto_escape: bool = True,
    ) -> msg_update:
        await asyncio.sleep(auto_edit)
        editing = await self.edit_message_text(
            chat_id,
            message_id,
            text,
            inline_keypad,
            parse_mode,
            meta_data,
            context=context,
            auto_escape=auto_escape
        )
        return editing # type: ignore
    
    def _schedule_handler(
        self,
        handler,
        update: Update | UpdateButton
    ):
        async def _run_handler(
            upd: Update | UpdateButton
        ):
            try:
                await handler(upd)
            except Exception as e:
                await self._process_on_error(
                    e=e,
                    update=upd
                )
        async def _wrapped():
            if self._middleware_manager.count > 0 and isinstance(update, Update):
                await self._middleware_manager.execute(update, _run_handler)
            else:
                await _run_handler(update)
        task = asyncio.create_task(_wrapped())
        self._pending_tasks.add(task)
        task.add_done_callback(self._pending_tasks.discard)
    
    # endregion

    # ═══════════════════════════════════
    # region 👤 Chat & User | مدیریت کاربر و چت
    # ═══════════════════════════════════

    async def get_me(
        self
    ) -> BotModel:
        """geting info accont bot / گرفتن اطلاعات اکانت ربات"""
        self.logger.debug("get_me called")
        if self.cache:
            cached = await self.cache.get("me")
            if cached:
                return cached
        result = await self.network.send_request(method="getMe")
        bot = result["bot"]
        if self.cache:
            await self.cache.set("me", bot)
        return BotModel(data=bot)

    async def get_chat(
        self,
        chat_id: str
    ) -> ChatModel:
        """geting info chat id info / گرفتن اطلاعات های یک چت"""
        self.logger.debug("get_chat called")
        Utils.check_id_raise(chat_id)
        if self.cache:
            cached = await self.cache.get(f"chat:{chat_id}")
            if cached:
                return cached
        data = {
            "chat_id": chat_id
        }
        result = await self.network.send_request(
            "getChat",
            data,
        )
        chat = result["chat"]
        if self.cache:
            await self.cache.set(f"chat:{chat_id}", chat)
        return ChatModel(data=chat)

    async def ban_chat_member(
        self,
        chat_id: str,
        user_id: str,
        wait_send: float | None = None,
        return_task: bool = False
    ) -> props | asyncio.Task[props]:
        """ban member in chat / بن کردن کاربر در چت"""
        self.logger.info("در حال استفاده از متئد ban_chat_member")
        
        async def _active():
            data = {
                "chat_id": chat_id,
                "user_id": user_id
            }
            result = await self.network.send_request("banChatMember", data)
            return props(result)
        
        result = await _send_helper(
            self, _active, channel="banning", return_task=return_task,
            wait_send=wait_send, chat_id=chat_id
        )
        return result # type: ignore
    
    async def unban_chat_member(
        self,
        chat_id: str,
        user_id: str,
        wait_send: float | None = None,
        return_task: bool = False
    ) -> props | asyncio.Task[props]:
        """un ban member in chat / آنبن کردن کاربر در چت"""
        self.logger.info("در حال استفاده از متئد unban_chat_member")

        async def _active():
            data = {
                "chat_id": chat_id,
                "user_id": user_id
            }
            result = await self.network.send_request("unbanChatMember", data)
            return props(result)
        
        result = await _send_helper(
            self, _active, channel="banning", return_task=return_task,
            wait_send=wait_send, chat_id=chat_id
        )
        return result # type: ignore
    
    ban_member = ban_chat_member
    unban_member = unban_chat_member
    ban_group_member = ban_chat_member
    unban_group_member = unban_chat_member
    ban_channel_member = ban_chat_member
    unban_channel_member = unban_chat_member

    
    async def check_join(
        self,
        chat_id: str,
        guid_channel: str,
        client: PyrubiClient
    ) -> bool:
        user = await self.get_chat(chat_id)
        search_by = user.username
        if not search_by:
            search_by = user.first_name
        info_members: dict = await client.get_all_members(
            object_guid=guid_channel,
            search_text=search_by
        ) # type: ignore
        members: list[dict] = info_members.get('in_chat_members', [])
        return any((m.get('username') == user.username or m.get("first_name") == user.first_name) for m in members)

    async def add_commands(
        self,
        command: str,
        description: str
    ) -> None:
        """add command to commands list / افزودن دستور به لیست دستورات"""
        self.logger.debug("add_commands called")
        self.list_commands.append(
            {
                "command": command.replace("/", ""),
                "description": description
            }
        )
    
    async def set_commands(
        self,
        list_commands: list | None = None
    ) -> dict:
        """set the commands for robot / تنظیم دستورات برای ربات"""
        self.logger.debug("set_commands called")
        result = await self.network.send_request(
            "setCommands",
            {
                "bot_commands": list_commands if list_commands else self.list_commands
            }
        )
        return result
    
    async def delete_commands(
        self
    ) -> dict:
        """clear the commands list / پاکسازی لیست دستورات"""
        self.logger.debug("delete_commands called")
        self.list_commands = []
        result = await self.set_commands()
        return result

    # endregion

    # ═══════════════════════════════════
    # region 📩 File Download | دانلود فایل
    # ═══════════════════════════════════

    
    async def download_me_profile(
        self,
        name_file: str = "bot_avatar.jpg",
        show_progress: bool = False,
        wait_send: float | None = None,
        return_task: bool = False,
        max_retries: int | None = None
    ) -> bool:
        self.logger.debug("download_me_profile called")
        bot = await self.get_me()
        avator_file_id = bot.avatar_file_id
        if avator_file_id:
            await self.download_file(
                id_file=avator_file_id,
                path=name_file,
                show_progress=show_progress,
                wait_send=wait_send,
                return_task=return_task,
                max_retries=max_retries,
            )
            self.logger.info("پروفایل ربات دانلود شد")
            return True
        return False

    
    async def get_file(
        self,
        id_file: str
    ) -> props:
        """getting info file / گرفتن اطلاعات فایل"""
        self.logger.debug("get_file called")
        result = await self.network.send_request("getFile", {"file_id": id_file})
        return props(result)

    
    async def get_download_file_url(
        self,
        id_file: str,
        wait_send: float | None = None,
        return_task: bool = False
    ) -> str | asyncio.Task[str]:
        """get download url file / گرفتن آدرس دانلود فایل"""
        self.logger.debug("get_download_file_url called")
        async def _active():
            if self.wait_manager and self.wait_manager.track_after_send:
                self.wait_manager.add_traffic(channel="uploading")
            wait_manager = wait_send or (await self.wait_manager.get_time("uploading") if self.wait_manager else None)
            if wait_manager:
                await asyncio.sleep(wait_manager)
            file = await self.get_file(id_file)
            url = file["download_url"]
            return url
        if return_task:
            return asyncio.create_task(_active())
        else:
            return await _active()

    
    async def download_by_url(
        self,
        url: str,
        path: str = "file",
        show_progress: bool = False,
        max_retries: int | None = None,
    ) -> None:
        if not self.show_progress is None:
            show_progress = self.show_progress
        download = await self.network.download(
            url,
            path,
            show_progress,
            max_retries
        )
        if download:
            self.logger.info("فایل دانلود شد")
        else:
            self.logger.error("خطا در دانلود فایل !")

    
    async def download_file(
        self,
        id_file: str ,
        path: str = "file",
        show_progress: bool = False,
        wait_send: float | None = None,
        return_task: bool = False,
        max_retries: int | None = None,
    ) -> None:
        """download file / دانلود فایل"""
        self.logger.debug("download_file called")
        async def _active():
            if self.wait_manager and self.wait_manager.track_after_send:
                self.wait_manager.add_traffic(channel="uploading")
            wait_manager = wait_send or (await self.wait_manager.get_time("uploading") if self.wait_manager else None)
            if wait_manager:
                await asyncio.sleep(wait_manager)
            url = await self.get_download_file_url(id_file)
            await self.download_by_url(url, path, show_progress, max_retries) # type: ignore
        if return_task:
            asyncio.create_task(_active())
        else:
            await _active()

    # endregion

    # ═══════════════════════════════════
    # region 📩 Sending Messages | ارسال پیام
    # ═══════════════════════════════════
    
    async def send_text(
        self,
        text: str,
        chat_id: str,
        inline_keypad: list | KeyPad | None = None,
        keypad: list | KeyPad | None = None,
        resize_keyboard: bool | None = True,
        on_time_keyboard: bool | None = False,
        disable_notification: bool | None = None,
        reply_to_message_id: str | None = None,
        auto_delete: int | None = None,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        meta_data: list | None = None,
        wait_send: float | None = None,
        return_task: bool = False,
        context: dict | None = None,
        auto_escape: bool = True,
    ) -> msg_update | asyncio.Task[msg_update]:
        """sending text to chat id"""
        self.logger.debug("send_text called")
        
        async def _active():
            _meta_data = meta_data if meta_data is not None else []
            _text = text
            _parse_mode = parse_mode

            if context:
                _text, extra_metadata = self.render(_text, parse_mode=_parse_mode, auto_escape=auto_escape, **context)
                _meta_data = _meta_data + extra_metadata
                if auto_escape:
                    _parse_mode = None

            metadata, _text = self._parse_mode_text(_text, _parse_mode)
            data = {
                "chat_id": chat_id,
                "text": _text,
                "disable_notification": disable_notification,
                "reply_to_message_id": reply_to_message_id
            }
            data = Utils.data_format(data, inline_keypad, keypad, resize_keyboard, on_time_keyboard, metadata, _meta_data)
            result = await self.network.send_request("sendMessage", data)
            result["chat_id"] = chat_id
            await self._manage_auto_delete(result, auto_delete)
            return msg_update(result, self)

        result = await _send_helper(
            self, _active, channel="sending", return_task=return_task,
            wait_send=wait_send, chat_id=chat_id, text=text
        )
        return result

    async def send_message(
        self,
        chat_id: str,
        text: str | None = None,
        inline_keypad: list | KeyPad | None = None,
        keypad: list | KeyPad | None = None,
        resize_keyboard: bool | None = True,
        on_time_keyboard: bool | None = False,
        disable_notification: bool | None = None,
        reply_to_message_id: str | None = None,
        auto_delete: int | None = None,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        meta_data: list | None = None,
        wait_send: float | None = None,
        return_task: bool = False,
        context: dict | None = None,
        auto_escape: bool = True,
        # file
        file: str  | Path  | bytes  | None = None,
        name_file: str | None = None,
        type_file: Literal["File", "Image", "Voice", "Music", "Gif" , "Video"] = "File",
        file_id: str | None = None,
        show_progress: bool = False,
        chunk_size: int = 1024 * 1024,
        # poll
        question: str | None = None,
        options: list | None = None,
        type_poll: Literal["Regular", "Quiz"] = "Regular",
        is_anonymous: bool = True,
        correct_option_index: int | None = None,
        allows_multiple_answers: bool = False,
        hint: str | None = None,
        # location
        latitude: str | None = None,
        longitude: str | None = None,
        # contact
        first_name: str | None = None,
        last_name: str | None = None,
        phone_number: str | None = None,
    ) -> msg_update | asyncio.Task[msg_update]:
        """send message / ارسال پیام"""
        if file_id:
            return await self.send_file_by_file_id(
                chat_id=chat_id,
                file_id=file_id,
                text=text,
                reply_to_message_id=reply_to_message_id,
                disable_notification=disable_notification,
                auto_delete=auto_delete,
                parse_mode=parse_mode,
                meta_data=meta_data,
                inline_keypad=inline_keypad,
                keypad=keypad,
                resize_keyboard=resize_keyboard,
                on_time_keyboard=on_time_keyboard,
                wait_send=wait_send,
                return_task=return_task,
                context=context,
                auto_escape=auto_escape,
            )
        elif file:
            return await self.base_send_file(
                chat_id=chat_id,
                file=file,
                name_file=name_file,
                text=text,
                reply_to_message_id=reply_to_message_id,
                type_file=type_file,
                disable_notification=disable_notification,
                auto_delete=auto_delete,
                parse_mode=parse_mode,
                meta_data=meta_data,
                inline_keypad=inline_keypad,
                keypad=keypad,
                resize_keyboard=resize_keyboard,
                on_time_keyboard=on_time_keyboard,
                show_progress=show_progress,
                chunk_size=chunk_size,
                wait_send=wait_send,
                return_task=return_task,
                context=context,
                auto_escape=auto_escape,
            )
        elif (not question is None) and (not options is None):
            return await self.send_poll(
                chat_id=chat_id,
                question=question,
                options=options,
                type_poll=type_poll,
                is_anonymous=is_anonymous,
                correct_option_index=correct_option_index,
                allows_multiple_answers=allows_multiple_answers,
                hint=hint,
                auto_delete=auto_delete,
                reply_to_message_id=reply_to_message_id,
                disable_notification=disable_notification,
                wait_send=wait_send,
                return_task=return_task
            )
        elif (not latitude is None) and (not longitude is None):
            return await self.send_location(
                chat_id=chat_id,
                latitude=latitude,
                longitude=longitude,
                disable_notification=disable_notification,
                reply_to_message_id=reply_to_message_id,
                auto_delete=auto_delete,
                wait_send=wait_send,
                return_task=return_task
            )
        elif first_name and last_name and phone_number:
            return await self.send_contact(
                chat_id=chat_id,
                first_name=first_name,
                last_name=last_name,
                phone_number=phone_number,
                reply_to_message_id=reply_to_message_id,
                disable_notification=disable_notification,
                auto_delete=auto_delete,
                inline_keypad=inline_keypad,
                wait_send=wait_send,
                return_task=return_task
            )
        elif not text is None:
            return await self.send_text(
                text=text,
                chat_id=chat_id,
                inline_keypad=inline_keypad,
                disable_notification=disable_notification,
                reply_to_message_id=reply_to_message_id,
                auto_delete=auto_delete,
                parse_mode=parse_mode,
                keypad=keypad,
                on_time_keyboard=on_time_keyboard,
                resize_keyboard=resize_keyboard,
                meta_data=meta_data,
                wait_send=wait_send,
                return_task=return_task,
                context=context,
                auto_escape=auto_escape,
            )
        raise ValueError("Please Write The Args !")

    async def send_poll(
        self,
        chat_id: str,
        question: str,
        options: list,
        type_poll: Literal["Regular", "Quiz"] = "Regular",
        is_anonymous: bool = True,
        correct_option_index: int | None = None,
        allows_multiple_answers: bool = False,
        hint: str | None = None,
        disable_notification: bool | None = None,
        reply_to_message_id: str | None = None,
        auto_delete: int | None = None,
        wait_send: float | None = None,
        return_task: bool = False
    ) -> msg_update | asyncio.Task[msg_update]:
        """sending poll to chat id / ارسال نظرسنجی به یک چت آیدی"""
        self.logger.debug("send_poll called")

        async def _active():
            if len(options) > 10:
                raise PollInvalid("len for options is logner from 10 option")
            data = {
                "chat_id": chat_id,
                "question": question,
                "options": options,
                "type": type_poll,
                "is_anonymous": is_anonymous,
                "correct_option_index": correct_option_index,
                "hint": hint,
                "allows_multiple_answers": allows_multiple_answers,
                "reply_to_message_id": reply_to_message_id,
                "disable_notification": disable_notification
            }
            result = await self.network.send_request(
                "sendPoll",
                data,
            )
            result["chat_id"] = chat_id
            await self._manage_auto_delete(result, auto_delete)
            return msg_update(result, self)

        result = await _send_helper(
            self, _active, channel="sending", return_task=return_task,
            wait_send=wait_send, chat_id=chat_id
        )
        return result

    async def send_location(
        self,
        chat_id: str,
        latitude: str,
        longitude: str,
        chat_keypad : str | None = None,
        disable_notification: bool | None = None,
        reply_to_message_id: str | None = None,
        chat_keypad_type: str | None = None,
        auto_delete: int | None = None,
        wait_send: float | None = None,
        return_task: bool = False
    ) -> msg_update | asyncio.Task[msg_update]:
        """sending location to chat id / ارسال لوکیشن(موقعیت مکانی) به یک چت آیدی"""
        self.logger.debug("send_location called")

        async def _active():
            data = {
                "chat_id": chat_id,
                "latitude": latitude,
                "longitude": longitude,
                "chat_keypad": chat_keypad,
                "disable_notification": disable_notification,
                "reply_to_message_id": reply_to_message_id,
                "chat_keypad_type": chat_keypad_type,
            }
            result = await self.network.send_request(
                "sendLocation",
                data,
            )
            result["chat_id"] = chat_id
            await self._manage_auto_delete(result, auto_delete)
            return msg_update(result, self)
        
        result = await _send_helper(
            self, _active, channel="sending", return_task=return_task,
            wait_send=wait_send, chat_id=chat_id
        )
        return result
    
    async def send_contact(
        self,
        chat_id: str,
        first_name: str,
        last_name: str,
        phone_number: str,
        chat_keypad : str | None = None,
        chat_keypad_type: str | None = None,
        inline_keypad: list | KeyPad | None = None,
        reply_to_message_id: str | None = None,
        disable_notification: bool | None = None,
        auto_delete: int | None = None,
        wait_send: float | None = None,
        return_task: bool = False
    ) -> msg_update | asyncio.Task[msg_update]:
        """sending contact to chat id / ارسال مخاطب به یک چت آیدی"""
        self.logger.debug("send_contact called")

        async def _active():
            data = {
                "chat_id": chat_id,
                "first_name": first_name,
                "last_name": last_name,
                "phone_number": phone_number,
                "chat_keypad": chat_keypad,
                "disable_notification": disable_notification,
                "chat_keypad_type": chat_keypad_type,
                "inline_keypad": inline_keypad,
                "reply_to_message_id": reply_to_message_id,
            }
            result = await self.network.send_request(
                "sendContact",
                data,
            )
            result["chat_id"] = chat_id
            await self._manage_auto_delete(result, auto_delete)
            return msg_update(result, self)
        result = await _send_helper(
            self, _active, channel="sending", return_task=return_task,
            wait_send=wait_send, chat_id=chat_id
        )
        return result
    
    async def forward_message(
        self,
        from_chat_id: str,
        message_id: str,
        to_chat_id: str,
        disable_notification : bool | None = None,
        auto_delete: int | None = None,
        wait_send: float | None = None,
        return_task: bool = False
    ) -> msg_update | asyncio.Task[msg_update]:
        """forwarding message to chat id / فوروارد پیام به یک چت آیدی"""
        self.logger.debug("forward_message called")

        async def _active():
            data = {
                "from_chat_id": from_chat_id,
                "message_id": message_id,
                "to_chat_id": to_chat_id,
                "disable_notification": disable_notification,
            }
            result = await self.network.send_request(
                "forwardMessage",
                data,
            )
            result["chat_id"] = to_chat_id
            await self._manage_auto_delete(result, auto_delete)
            return msg_update(result, self)
        
        result = await _send_helper(
            self, _active, channel="forwarding", return_task=return_task,
            wait_send=wait_send, chat_id=from_chat_id, to_chat_id=to_chat_id
        )
        return result

    async def forward_messages(
        self,
        from_chat_id: str,
        message_ids: list,
        to_chat_id: str,
        disable_notification: bool | None = None,
        auto_delete: int | None = None,
        wait_send: float | None = None,
        return_task: bool = False
    ) -> list[msg_update] | list[asyncio.Task[msg_update]]:
        """forwarding messages to chat id / فوروارد چند پیام به یک چت آیدی"""
        tasks: list = [
            self.forward_message(
                from_chat_id,
                ms_id,
                to_chat_id,
                disable_notification,
                auto_delete,
                wait_send=wait_send,
                return_task=return_task
            )
            for ms_id in message_ids
        ]
        return await asyncio.gather(*tasks)  # type: ignore[call-overload]

    # ═══════════════════════════════════
    # region ✏️ Messaging | ویرایش و مدیریت پیام
    # ═══════════════════════════════════
    
    async def edit_message_text(
        self,
        chat_id: str,
        message_id: str,
        text: str,
        inline_keypad: list | KeyPad | None = None,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        meta_data: list | None = None,
        wait_send: float | None = None,
        return_task: bool = False,
        context: dict | None = None,
        auto_escape: bool = True,
    ) -> msg_update | asyncio.Task[msg_update]:
        """editing message text / ویرایش متن پیام"""
        self.logger.debug("edit_message_text called")

        async def _active():
            _meta_data = meta_data if meta_data is not None else []
            _text = text
            _parse_mode = parse_mode

            if context:
                _text, extra_metadata = self.render(_text, parse_mode=_parse_mode, auto_escape=auto_escape, **context)
                _meta_data = _meta_data + extra_metadata
                if auto_escape:
                    _parse_mode = None
            
            metadata, _text  = self._parse_mode_text(_text, _parse_mode)
            data = {"chat_id": chat_id, "message_id": message_id, "text": _text}
            data = Utils.data_format(data, inline_keypad, metadata=metadata, meta_data=_meta_data)
            result = await self.network.send_request(
                "editMessageText",
                data,
            )
            result["chat_id"] = chat_id
            return msg_update(result, self)

        result = await _send_helper(
            self, _active, channel="editing", return_task=return_task,
            wait_send=wait_send, chat_id=chat_id
        )
        return result
    
    edit_text = edit_message_text
    edit_message = edit_message_text
    
    async def auto_edit(
        self,
        chat_id: str,
        message_id: str,
        text: str,
        auto_edit: int,
        inline_keypad: list | KeyPad | None = None,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        meta_data: list = [],
        separate_task: bool = False,
        context: dict | None = None,
        auto_escape: bool = True,
    ) -> msg_update | None:
        """auto edit message text {time_sleep} time s / ویرایش خودکار متن پیام بعد از فلان مقدار ثانیه"""
        async def _edit():
            Utils.check_message_id_raise(message_id)
            return await self._auto_edit(
                chat_id=chat_id,
                message_id=message_id,
                text=text,
                auto_edit=auto_edit,
                inline_keypad=inline_keypad,
                parse_mode=parse_mode,
                meta_data=meta_data,
                context=context,
                auto_escape=auto_escape
            )
        if separate_task:
            asyncio.create_task(
                _edit()
            )
            return None
        else:
            await _edit()

    # endregion

    # ═══════════════════════════════════
    # region ❌ Deleteing Message | حذف پیام
    # ═══════════════════════════════════

    
    async def delete_message(
        self,
        chat_id: str,
        message_id: str,
        wait_send: float | None = None,
        return_task: bool = False
    ) -> props | asyncio.Task[props]:
        """delete message / پاکسازی(حذف) یک پیام"""
        self.logger.debug("delete_message called")

        async def _active():
            data = {
                "chat_id": chat_id,
                "message_id": message_id
            }
            result = await self.network.send_request(
                "deleteMessage",
                data,
            )
            return props(result)

        result = await _send_helper(
            self, _active, channel="deleting", return_task=return_task,
            wait_send=wait_send, chat_id=chat_id
        )
        return result # type: ignore
    
    async def auto_delete(
        self,
        chat_id: str,
        message_id: str,
        time_sleep: float,
        separate_task: bool = False
    ) -> props | None:
        """auto delete message next {time_sleep} time s / حذف خودکار پیام بعد از فلان مقدار ثانیه"""
        if separate_task:
            asyncio.create_task(
                self._auto_delete(
                    chat_id=chat_id,
                    message_id=message_id,
                    time_sleep=time_sleep
                )
            )
            return None
        else:
            return await self._auto_delete(
                chat_id=chat_id,
                message_id=message_id,
                time_sleep=time_sleep
            )

    # endregion
    
    async def upload_file(
        self,
        url: str,
        file_name: str,
        file: str | Path | bytes,
        show_progress: bool = False,
        chunk_size: int = 1024 * 1024
    ) -> dict:
        """upload file to rubika server / آپلود فایل در سرور روبیکا"""
        self.logger.debug("upload_file called")
        if not self.show_progress is None:
            show_progress = self.show_progress
        response = await self.network.upload(url, file, file_name, show_progress, chunk_size)
        return response
    
    async def send_file_by_file_id(
        self,
        chat_id: str,
        file_id: str,
        text: str | None = None,
        reply_to_message_id: str | None = None,
        disable_notification: bool | None = None,
        auto_delete: int | None = None,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        meta_data: list | None = None,
        inline_keypad: list | KeyPad | None = None,
        keypad: list | KeyPad | None = None,
        resize_keyboard: bool | None = True,
        on_time_keyboard: bool | None = False,
        wait_send: float | None = None,
        return_task: bool = False,
        context: dict | None = None,
        auto_escape: bool = True,
    ) -> msg_update | asyncio.Task[msg_update]:
        """sending file by file id / ارسال فایل با آیدی فایل"""
        self.logger.debug("send_file_by_id called")

        async def _active():
            _text = text
            _meta_data = meta_data if meta_data is not None else []
            _parse_mode = parse_mode

            if context and _text:
                _text, extra_metadata = self.render(_text, parse_mode=_parse_mode, auto_escape=auto_escape, **context)
                _meta_data = _meta_data + extra_metadata
                if auto_escape:
                    _parse_mode = None
            
            metadata = []
            Utils.check_id_raise(chat_id)
            if _text:
                metadata, _text  = self._parse_mode_text(_text, _parse_mode)
            data = {
                "chat_id": chat_id,
                "text": _text,
                "file_id": file_id,
                "reply_to_message_id": reply_to_message_id,
                "disable_notification": disable_notification,
            }
            data = Utils.data_format(data, inline_keypad,keypad,resize_keyboard,on_time_keyboard, metadata=metadata, meta_data=_meta_data)
            sending = await self.network.send_request("sendFile", data)
            sending["chat_id"] = chat_id
            await self._manage_auto_delete(sending, auto_delete)
            return msg_update(sending, self)
        
        result = await _send_helper(
            self, _active, channel="sending", return_task=return_task,
            wait_send=wait_send, chat_id=chat_id
        )
        return result
    
    async def request_send_file(
        self,
        type: Literal["File", "Image", "Voice", "Music", "Gif" , "Video"] = "File"
    ) -> dict:
        return await self.network.send_request(
            "requestSendFile",
            {
                "type": type
            }
        )

    async def base_send_file(
        self,
        chat_id: str,
        file: str  | Path  | bytes,
        name_file: str | None = None,
        text : str | None = None,
        reply_to_message_id : str | None = None,
        type_file: Literal["File", "Image", "Voice", "Music", "Gif" , "Video"] = "File",
        disable_notification : bool | None = None,
        auto_delete: int | None = None,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        meta_data: list | None = None,
        inline_keypad: list | KeyPad | None = None,
        keypad: list | KeyPad | None = None,
        resize_keyboard: bool | None = True,
        on_time_keyboard: bool | None = False,
        show_progress: bool = False,
        chunk_size: int = 1024 * 1024,
        wait_send: float | None = None,
        return_task: bool = False,
        context: dict | None = None,
        auto_escape: bool = True,
    ) -> msg_update | asyncio.Task[msg_update]:
        """sending file with types ['File', 'Image', 'Voice', 'Music', 'Gif' , 'Video'] / ارسال فایل با نوع های فایل و عکس و پیغام صوتی و موزیک و گیف و ویدیو"""
        self.logger.debug("base_send_file called")

        async def _active():
            request_file = await self.request_send_file(type_file)
            upload_url_file = request_file["upload_url"]
            _name_file = name_file
            if not _name_file:
                _name_file = Utils.format_file(type_file)
            if not _name_file:
                raise ValueError("type file is invalud !")
            upload_file = await self.upload_file(
                url=upload_url_file,
                file_name=_name_file,
                file=file,
                show_progress=show_progress,
                chunk_size=chunk_size
            )
            file_id = upload_file["file_id"]
            send = await self.send_file_by_file_id(
                chat_id=chat_id,
                file_id=file_id,
                text=text,
                reply_to_message_id=reply_to_message_id,
                disable_notification=disable_notification,
                parse_mode=parse_mode,
                auto_delete=auto_delete,
                meta_data=meta_data,
                inline_keypad=inline_keypad,
                keypad=keypad,
                resize_keyboard=resize_keyboard,
                on_time_keyboard=on_time_keyboard,
                context=context,
                auto_escape=auto_escape
            )
            sended = send.to_dict() # type: ignore
            sended["file_id"] = file_id
            sended["type_file"] = type_file
            if isinstance(file, (bytes, bytearray, memoryview)):
                size_file = len(file)
            if isinstance(file, (str, Path)):
                file_str = str(file)
                if file_str.startswith("http://") or file_str.startswith("https://"):
                    try:
                        response = await self.network.request(file_str, type_send="HEAD")
                        size_file = int(response.headers.get("content-length", 0))
                    except:
                        size_file = 0
                else:
                    size_file = os.path.getsize(file_str)
            elif isinstance(file, (bytes, bytearray, memoryview)):
                size_file = len(file)
            else:
                raise FileExistsError("file not found !")
            sended["size_file"] = size_file
            return msg_update(sended, self)
        
        result = await _send_helper(
            self, _active, channel="sending", return_task=return_task,
            wait_send=wait_send, chat_id=chat_id
        )
        return result

    async def send_file(
        self,
        chat_id: str,
        file: str  | Path  | bytes,
        name_file: str | None = None,
        text: str | None = None,
        reply_to_message_id: str | None = None,
        disable_notification: bool | None = None,
        auto_delete: int | None = None,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        meta_data: list | None = None,
        inline_keypad: list | KeyPad | None = None,
        keypad: list | KeyPad | None = None,
        resize_keyboard: bool | None = True,
        on_time_keyboard: bool | None = False,
        show_progress: bool = False,
        chunk_size: int = 1024 * 1024,
        wait_send: float | None = None,
        return_task: bool = False,
        context: dict | None = None,
        auto_escape: bool = True,
    ) -> msg_update | asyncio.Task[msg_update]:
        "ارسال فایل / send file"
        self.logger.debug("send_file called")
        result = await self.base_send_file(
            chat_id=chat_id,
            file=file,
            name_file=name_file,
            text=text,
            reply_to_message_id=reply_to_message_id,
            type_file="File",
            disable_notification=disable_notification,
            auto_delete=auto_delete,
            parse_mode=parse_mode,
            meta_data=meta_data,
            inline_keypad=inline_keypad,
            keypad=keypad,
            resize_keyboard=resize_keyboard,
            on_time_keyboard=on_time_keyboard,
            show_progress=show_progress,
            chunk_size=chunk_size,
            wait_send=wait_send,
            return_task=return_task,
            context=context,
            auto_escape=auto_escape
        )
        return result

    send_document = send_file

    async def send_image(
        self,
        chat_id: str,
        image: str  | Path  | bytes,
        name_file: str | None = None,
        text : str | None = None,
        reply_to_message_id : str | None = None,
        disable_notification: bool | None = None,
        auto_delete: int | None = None,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        meta_data: list | None = None,
        inline_keypad: list | KeyPad | None = None,
        keypad: list | KeyPad | None = None,
        resize_keyboard: bool | None = True,
        on_time_keyboard: bool | None = False,
        show_progress: bool = False,
        chunk_size: int = 1024 * 1024,
        wait_send: float | None = None,
        return_task: bool = False,
        context: dict | None = None,
        auto_escape: bool = True,
    ) -> msg_update | asyncio.Task[msg_update]:
        """sending image / ارسال تصویر"""
        self.logger.debug("send_image called")
        result = await self.base_send_file(
            chat_id=chat_id,
            file=image,
            name_file=name_file,
            text=text,
            reply_to_message_id=reply_to_message_id,
            type_file="Image",
            disable_notification=disable_notification,
            auto_delete=auto_delete,
            parse_mode=parse_mode,
            meta_data=meta_data,
            inline_keypad=inline_keypad,
            keypad=keypad,
            resize_keyboard=resize_keyboard,
            on_time_keyboard=on_time_keyboard,
            show_progress=show_progress,
            chunk_size=chunk_size,
            wait_send=wait_send,
            return_task=return_task,
            context=context,
            auto_escape=auto_escape
        )
        return result

    send_photo = send_image
    send_picture = send_image

    async def send_video(
        self,
        chat_id: str,
        video: str  | Path  | bytes,
        name_file: str | None = None,
        text : str | None = None,
        reply_to_message_id : str | None = None,
        disable_notification : bool | None = None,
        auto_delete: int | None = None,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        meta_data: list | None = None,
        inline_keypad: list | KeyPad | None = None,
        keypad: list | KeyPad | None = None,
        resize_keyboard: bool | None = True,
        on_time_keyboard: bool | None = False,
        show_progress: bool = False,
        chunk_size: int = 1024 * 1024,
        wait_send: float | None = None,
        return_task: bool = False,
        context: dict | None = None,
        auto_escape: bool = True,
    ) -> msg_update | asyncio.Task[msg_update]:
        """sending video / ارسال ویدیو"""
        self.logger.debug("send_video called")
        result = await self.base_send_file(
            chat_id=chat_id,
            file=video,
            name_file=name_file,
            text=text,
            reply_to_message_id=reply_to_message_id,
            type_file="Video",
            disable_notification=disable_notification,
            auto_delete=auto_delete,
            parse_mode=parse_mode,
            meta_data=meta_data,
            inline_keypad=inline_keypad,
            keypad=keypad,
            resize_keyboard=resize_keyboard,
            on_time_keyboard=on_time_keyboard,
            show_progress=show_progress,
            chunk_size=chunk_size,
            wait_send=wait_send,
            return_task=return_task,
            context=context,
            auto_escape=auto_escape
        )
        return result

    async def send_voice(
        self,
        chat_id: str,
        voice: str  | Path  | bytes,
        name_file: str | None = None,
        text : str | None = None,
        reply_to_message_id: str | None = None,
        disable_notification: bool | None = None,
        auto_delete: int | None = None,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        meta_data: list | None = None,
        inline_keypad: list | KeyPad | None = None,
        keypad: list | KeyPad | None = None,
        resize_keyboard: bool | None = True,
        on_time_keyboard: bool | None = False,
        show_progress: bool = False,
        chunk_size: int = 1024 * 1024,
        wait_send: float | None = None,
        return_task: bool = False,
        context: dict | None = None,
        auto_escape: bool = True,
    ) -> msg_update | asyncio.Task[msg_update]:
        """sending voice / ارسال ویس"""
        self.logger.debug("send_voice called")
        result = await self.base_send_file(
            chat_id=chat_id,
            file=voice,
            name_file=name_file,
            text=text,
            reply_to_message_id=reply_to_message_id,
            type_file="Voice",
            disable_notification=disable_notification,
            auto_delete=auto_delete,
            parse_mode=parse_mode,
            meta_data=meta_data,
            inline_keypad=inline_keypad,
            keypad=keypad,
            resize_keyboard=resize_keyboard,
            on_time_keyboard=on_time_keyboard,
            show_progress=show_progress,
            chunk_size=chunk_size,
            wait_send=wait_send,
            return_task=return_task,
            context=context,
            auto_escape=auto_escape
        )
        return result

    async def send_music(
        self,
        chat_id: str,
        music: str  | Path  | bytes,
        name_file: str | None = None,
        text: str | None = None,
        reply_to_message_id: str | None = None,
        disable_notification: bool | None = None,
        auto_delete: int | None = None,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        meta_data: list | None = None,
        inline_keypad: list | KeyPad | None = None,
        keypad: list | KeyPad | None = None,
        resize_keyboard: bool | None = True,
        on_time_keyboard: bool | None = False,
        show_progress: bool = False,
        chunk_size: int = 1024 * 1024,
        wait_send: float | None = None,
        return_task: bool = False,
        context: dict | None = None,
        auto_escape: bool = True,
    ) -> msg_update | asyncio.Task[msg_update]:
        """sending music / ارسال موزیک"""
        self.logger.debug("send_music called")
        result = await self.base_send_file(
            chat_id=chat_id,
            file=music,
            name_file=name_file,
            text=text,
            reply_to_message_id=reply_to_message_id,
            type_file="Music",
            disable_notification=disable_notification,
            auto_delete=auto_delete,
            parse_mode=parse_mode,
            meta_data=meta_data,
            inline_keypad=inline_keypad,
            keypad=keypad,
            resize_keyboard=resize_keyboard,
            on_time_keyboard=on_time_keyboard,
            show_progress=show_progress,
            chunk_size=chunk_size,
            wait_send=wait_send,
            return_task=return_task,
            context=context,
            auto_escape=auto_escape
        )
        return result

    async def send_gif(
        self,
        chat_id: str,
        gif: str  | Path  | bytes,
        name_file: str | None = None,
        text : str | None = None,
        reply_to_message_id : str | None = None,
        disable_notification : bool | None = None,
        auto_delete: int | None = None,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        meta_data: list | None = None,
        inline_keypad: list | KeyPad | None = None,
        keypad: list | KeyPad | None = None,
        resize_keyboard: bool | None = True,
        on_time_keyboard: bool | None = False,
        show_progress: bool = False,
        chunk_size: int = 1024 * 1024,
        wait_send: float | None = None,
        return_task: bool = False,
        context: dict | None = None,
        auto_escape: bool = True,
    ) -> msg_update | asyncio.Task[msg_update]:
        """sending gif / ارسال گیف"""
        self.logger.debug("send_gif called")
        result = await self.base_send_file(
            chat_id=chat_id,
            file=gif,
            name_file=name_file,
            text=text,
            reply_to_message_id=reply_to_message_id,
            type_file="Gif",
            disable_notification=disable_notification,
            auto_delete=auto_delete,
            parse_mode=parse_mode,
            meta_data=meta_data,
            inline_keypad=inline_keypad,
            keypad=keypad,
            resize_keyboard=resize_keyboard,
            on_time_keyboard=on_time_keyboard,
            show_progress=show_progress,
            chunk_size=chunk_size,
            wait_send=wait_send,
            return_task=return_task,
            context=context,
            auto_escape=auto_escape
        )
        return result

    async def send_sticker(
        self,
        chat_id: str,
        id_sticker: str,
        reply_to_message_id: str | None = None,
        disable_notification: bool | None = None,
        auto_delete: int | None = None,
        wait_send: float | None = None,
        return_task: bool = False
    ) -> msg_update | asyncio.Task[msg_update]:
        """sending sticker by id / ارسال استیکر با آیدی"""
        self.logger.debug("send_stiker called")
        
        async def _active():
            data = {
                "chat_id": chat_id,
                "sticker_id": id_sticker,
                "reply_to_message_id": reply_to_message_id,
                "disable_notification": disable_notification
            }
            sender = await self.network.send_request("sendSticker", data)
            sender["chat_id"] = chat_id
            await self._manage_auto_delete(sender, auto_delete)
            return msg_update(sender, self)
        
        result = await _send_helper(
            self, _active, channel="sending", return_task=return_task,
            wait_send=wait_send, chat_id=chat_id
        )
        return result
    
    async def resend_message(
        self,
        message_id: str,
        from_chat_id: str,
        to_chat_id: str,
        auto_delete: int | None = None,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        meta_data: list | None = None,
        name_save_file: str | None = None,
        show_progress: bool = False,
        chunk_size: int = 1024 * 1024,
        wait_send: float | None = None,
        return_task: bool = False,
        context: dict | None = None,
        auto_escape: bool = True,
        max_retries: int | None = None,
    ) -> msg_update | asyncio.Task[msg_update]:
        """re send message / ارسال مجدد پیام"""
        self.logger.debug("resend_message called")
        
        async def _active():
            msg = await self.get_message_by_id(from_chat_id, message_id)
            if msg:
                text = msg.text
                file_file_id = msg.file_id
                file_file_name = str(msg.file_name)

                _text = text
                _meta_data = meta_data if meta_data is not None else []
                _parse_mode = parse_mode
                if context and _text:
                    _text, extra_metadata = self.render(_text, parse_mode=_parse_mode, auto_escape=auto_escape, **context)
                    _meta_data = _meta_data + extra_metadata
                    if auto_escape:
                        _parse_mode = None
                
                if (not file_file_id) and _text:
                    return await self.send_text(
                        text=_text,
                        chat_id=to_chat_id,
                        auto_delete=auto_delete,
                        parse_mode=_parse_mode,
                        meta_data=_meta_data
                    )
                if file_file_id:
                    download_name = name_save_file if name_save_file else file_file_name
                    type_file = Utils.type_file(name_file=download_name)
                    await self.download_file(
                        file_file_id,
                        download_name,
                        show_progress,
                        max_retries
                    )
                    return await self.base_send_file(
                        chat_id=to_chat_id,
                        file=download_name,
                        name_file=download_name,
                        text=_text,
                        auto_delete=auto_delete,
                        parse_mode=_parse_mode,
                        meta_data=_meta_data,
                        show_progress=show_progress,
                        chunk_size=chunk_size,
                        type_file=type_file
                    )
                self.logger.warning("Can't Find Message !")
                raise KeyError("Can't Find Message !")
            else:
                self.logger.warning("Can't Find Message !")
                raise KeyError("Can't Find Message !")
        
        result = await _send_helper(
            self, _active, channel="sending", return_task=return_task,
            wait_send=wait_send, chat_id=from_chat_id, to_chat_id=to_chat_id
        )
        return result

    copy_message = resend_message

    # endregion

    # ═══════════════════════════════════
    # region 🎛️ Handlers | دکوراتورهای ثبت هندلر
    # ═══════════════════════════════════

    def add_conversation(
        self,
        conversation: 'Conversation'
    ):
        self._conversation_manager.add(conversation)

    def on_message(self,
        filters: Filter | None = None,
        edited_messages: Literal[False, True, "both"] = False,
        deleted_messages: Literal[False, True, "both"] = False,
    ):
        """Receive new Polling messages / دریافت پیام جدید با Polling"""
        def decorator(handler):
            self.add_handler(
                handler=handler,
                type_handler="polling",
                filters=filters,
                edited_messages=edited_messages,
                deleted_messages=deleted_messages,
            )
            return handler
        return decorator

    def on_message_updates(
        self,
        filters: Filter | None = None,
        edited_messages: Literal[False, True, "both"] = False,
        deleted_messages: Literal[False, True, "both"] = False,
    ):
        """Receive messages through Webhook / دریافت پیام از وب‌هوک"""
        def decorator(handler):
            self.add_handler(
                handler=handler,
                type_handler="webhook",
                filters=filters,
                edited_messages=edited_messages,
                deleted_messages=deleted_messages,
            )
            return handler
        return decorator

    def on_button_updates(
        self,
        filters: InlineFilter | None = None
    ):
        """دکوراتور دریافت کلیک های دکمه های شیشه ای"""
        def decorator(handler):
            self.add_handler(
                handler=handler,
                type_handler="button",
                filters=filters
            )
            return handler
        return decorator
    
    on_button = on_button_updates
    
    def on_button_url(
        self,
        path_url: str,
        filters: InlineFilter | None = None
    ):
        """دکوراتور دریافت کلیک های دکمه های شیشه ای از آدرس خاص"""
        def decorator(handler):
            self.add_handler(
                handler=handler,
                type_handler="button_url",
                filters=filters,
                path_url=path_url,
            )
            return handler
        return decorator
    
    on_inline = on_button
    on_inline_button = on_button
    on_glass_buttons = on_button
    on_glass_inline = on_button
    
    def on_edit_updates(self, filters: Filter | None = None):
        """Receive edited Webhook messages / دریافت ویرایش پیام از وب‌هوک"""
        return self.on_message_updates(filters=filters, edited_messages=True)

    def on_delete_updates(self, filters: Filter | None = None):
        """Receive deleted Webhook messages / دریافت حذف پیام از وب‌هوک"""
        return self.on_message_updates(filters=filters, deleted_messages=True)

    def on_all_message_updates(self, filters: Filter | None = None):
        """Receive all Webhook message events / دریافت همه رویدادهای پیام وب‌هوک"""
        return self.on_message_updates(
            filters=filters, edited_messages="both", deleted_messages="both"
        )

    def on_edit(self, filters: Filter | None = None):
        """Receive edited Polling messages / دریافت ویرایش پیام با Polling"""
        return self.on_message(filters=filters, edited_messages=True)

    def on_delete(self, filters: Filter | None = None):
        """Receive deleted Polling messages / دریافت حذف پیام با Polling"""
        return self.on_message(filters=filters, deleted_messages=True)

    def on_all_message(self, filters: Filter | None = None):
        """Receive all Polling message events / دریافت همه رویدادهای پیام Polling"""
        return self.on_message(
            filters=filters, edited_messages="both", deleted_messages="both"
        )

    def failover_on_message(
        self,
        filters: Filter | None = None,
        edited_messages: Literal[False, True, "both"] = False,
        deleted_messages: Literal[False, True, "both"] = False,
        config: AutoFailoverConfig | None = None,
    ):
        """Register a Webhook<->Polling handler / ثبت هندلر با جابه‌جایی خودکار"""
        # This decorator is the opt-in; normal message decorators stay unchanged.
        def decorator(handler):
            self.add_handler(
                handler=handler,
                type_handler="failover",
                filters=filters,
                edited_messages=edited_messages,
                deleted_messages=deleted_messages,
                failover_config=config,
            )
            return handler
        return decorator

    def failover_on_delete(
        self,
        filters: Filter | None = None,
        config: AutoFailoverConfig | None = None
    ):
        """Register a Webhook<->Polling handler (But Message Delete) / ثبت هندلر با جابه‌جایی خودکار (فقط حذف پیام)"""
        return self.failover_on_message(
            filters=filters,
            deleted_messages=True,
            config=config
        )
    
    def failover_on_edit(
        self,
        filters: Filter | None = None,
        config: AutoFailoverConfig | None = None
    ):
        """Register a Webhook<->Polling handler (But Message Edit) / ثبت هندلر با جابه‌جایی خودکار (فقط ویرایش پیام)"""
        return self.failover_on_message(
            filters=filters,
            edited_messages=True,
            config=config
        )

    on_message_webhook = on_message_updates
    on_message_webhook_delete = on_delete_updates
    on_message_webhook_edit = on_edit_updates
    on_message_webhook_all = on_all_message_updates
    on_message_polling = on_message
    on_message_polling_delete = on_delete
    on_message_polling_edit = on_edit
    on_message_polling_all = on_all_message
    failover_on_message_updates = failover_on_message
    failover_on_delete_updates = failover_on_delete
    failover_on_edit_updates = failover_on_edit

    
    def on_ready(self):
        """when client read for sending requests and no has problem for sending requests / زمانی که کلاینت آماده برای ارسال درخواست ها شده و مشکلی برای ارسال درخواست ها ندارد"""
        def decorator(func):
            self.add_handler(
                handler=func,
                type_handler="ready"
            )
            return func
        return decorator
    
    def on_start(self):
        """when client read for sending requests / زمانی که کلاینت آماده برای ارسال درخواست ها شد"""
        def decorator(func):
            self.add_handler(
                handler=func,
                type_handler="start"
            )
            return func
        return decorator
    
    on_startup = on_start

    def on_run(self):
        """when start getting messages / زمانی که گرفتن پیام ها شروع می شود"""
        def decorator(func):
            self.add_handler(
                handler=func,
                type_handler="run"
            )
            return func
        return decorator

    def on_live(self):
        """when mode polling , getting new messages / زمانی که در حالت پولینگ به پیام های جدید می رسد"""
        def decorator(func):
            self.add_handler(
                handler=func,
                type_handler="live"
            )
            return func
        return decorator
    
    def on_error(
        self,
        error_detail: Literal["full", "message", "type"] = "message"
    ):
        """Manage errors in handlers / مدیریت خطا های پیش بینی نشده در هندلر ها"""
        def decorator(func):
            self.add_handler(
                handler=func,
                type_handler="error",
                error_detail=error_detail
            )
            return func
        return decorator
    
    def middleware(
        self,
        filters: Filter | None = None
    ):
        """دکوراتور برای ثبت Middleware"""
        def decorator(func: Callable):
            self.add_handler(func, "middleware", filters)
            return func
        return decorator
    
    def load_plugins(self, folder: str = "plugins") -> int:
        """لود کردن همه پلاگین‌ها از پوشه."""
        if os.path.exists(folder):
            for f in os.listdir(folder):
                if f.endswith(".py") and not f.startswith("_"):
                    name = f[:-3]
                    if name not in self._loaded_plugins:
                        self._loaded_plugins.append(name)
        return PluginManager.load(self, folder, self.logger)
    
    def load_plugin(self, filepath: str) -> bool:
        """لود یه پلاگین خاص."""
        if os.path.exists(filepath):
            self._loaded_plugins.append(filepath)
        return PluginManager.load_single(self, filepath, self.logger)
    
    def on_shutdown(
        self
    ):
        """دکوراتور برای زمانی که ربات خاموش می‌شود (هنگام close)."""
        def decorator(func: Callable):
            self.add_handler(func, "shutdown")
            return func
        return decorator
    
    on_close = on_shutdown

    def before_send(self):
        """دکوراتور - قبل از هر ارسال اجرا می‌شود. اگر False برگرداند، ارسال لغو می‌شود"""
        def decorator(func: Callable):
            self.add_handler(
                func,
                "before_send"
            )
            return func
        return decorator

    def after_send(self):
        """دکوراتور - بعد از هر ارسال اجرا می‌شود."""
        def decorator(func: Callable):
            self.add_handler(
                func,
                "after_send"
            )
            return func
        return decorator
    
    def before_run(self):
        """دکوراتور برای ثبت handler قبل از اجرای run"""
        def decorator(func):
            self.add_handler(
                func,
                "before_run"
            )
            return func
        return decorator

    def after_run(self):
        """دکوراتور برای ثبت handler بعد از اجرای run"""
        def decorator(func):
            self.add_handler(
                func,
                "after_run"
            )
            return func
        return decorator
    
    def on_log(self):
        def decorator(func):
            self.add_handler(
                func,
                "log"
            )
            return func
        return decorator
    
    def add_handler(
        self,
        handler: Callable | tuple,
        type_handler: Literal[
            "polling",
            "webhook",
            "failover",
            "button",
            "start",
            "ready",
            "run",
            "live",
            "error",
            "conversation",
            "middleware",
            "shutdown",
            "button_url",
            "webhook_url",
            "before_send",
            "after_send",
            "before_run",
            "after_run",
            "log",
        ],
        filters: Filter | InlineFilter | None = None,
        edited_messages: Literal[False, True, "both"] = False,
        deleted_messages: Literal[False, True, "both"] = False,
        failover_config: AutoFailoverConfig | None = None,
        **values
    ):
        """Register a callback / ثبت هندلر"""
        if isinstance(handler, Callable):
            if type_handler in ("polling", "webhook", "failover"):
                self._fetch_messages = True
                @wraps(handler)
                async def wrapped(update):
                    try:
                        # Run filters only in the shared pipeline to avoid duplicate filter calls.
                        return await Utils.run_handler(
                            handler,
                            update
                        )

                    except Exception as e:
                        await self._process_on_error(
                            e=e
                        )
                        return None
                handler_info = {
                    "handler": wrapped,
                    "filters": filters,
                    "edited_messages": edited_messages,
                    "deleted_messages": deleted_messages,
                    "source": type_handler,
                }
                if edited_messages:
                    self._fetch_edit = True
                if type_handler == "polling":
                    self._fetch_messages_polling = True
                    self._message_handlers_polling.append(handler_info)
                elif type_handler == "webhook":
                    self._fetch_messages_webhook = True
                    self._message_handlers_webhook.append(handler_info)
                else:
                    # Store one logical handler shared by both transports; start with Webhook
                    # The seen set handles duplicate payloads, pending stores candidates, and
                    # the recovery streak controls when Webhook becomes preferred again
                    handler_info.update({
                        "source": "failover",
                        "active_source": "webhook",
                        "auto_failover_config": self._resolve_auto_failover_config(failover_config),
                        "_auto_failover_recovery_streak": 0,
                        "_auto_failover_seen": set(),
                        "_auto_failover_seen_order": deque(),
                        "_auto_failover_pending": {},
                    })
                    self._fetch_messages_polling = True
                    self._fetch_messages_webhook = True
                    self._message_handlers_failover.append(handler_info)
                return wrapped
            elif type_handler == "button":
                self._fetch_buttons = True
                self._button_handlers.append(
                    {
                        "handler": handler,
                        "filters": filters
                    }
                )
            elif type_handler == "start":
                self._on_start_handlers.append(handler)
            elif type_handler == "ready":
                self._on_ready_handlers.append(handler)
            elif type_handler == "run":
                self._on_run_handlers.append(handler)
            elif type_handler == "live":
                self._on_live_handlers.append(handler)
            elif type_handler == "error":
                handler_info = {
                    "handler": handler
                }
                handler_info.update(
                    values
                )
                self._on_error_handlers.append(
                    handler_info
                )
            elif type_handler == "middleware":
                self._middleware_manager.add(handler, filters) # type: ignore
            elif type_handler == "shutdown":
                self._on_shutdown_handlers.append(handler)
            elif type_handler == "button_url":
                self._button_handlers_url.append(
                    {
                        "handler": handler,
                        "filters": filters,
                        "url": values["path_url"]
                    }
                )
            elif type_handler == "webhook_url":
                self._webhook_handlers_url.append(
                    {
                        "handler": handler,
                        "filters": filters,
                        "url": values["path_url"]
                    }
                )
            elif type_handler == "log":
                self._log_handlers.append(handler)
            elif type_handler == "before_send":
                self._before_send_handlers.append(handler)
            elif type_handler == "after_send":
                self._after_send_handlers.append(handler)
            elif type_handler == "before_run":
                self._before_run_handlers.append(handler)
            elif type_handler == "after_run":
                self._after_run_handlers.append(handler)
        else:
            if type_handler == "conversation":
                name, conv = handler
                self._conversation_manager.add(conv)
    
    # endregion

    # ═══════════════════════════════════
    # region ⚙️ Processs | فرایند ها
    # ═══════════════════════════════════

    async def _process_message_update(
        self,
        message: dict[str, Any],
        handler_infos: list[dict[str, Any]],
        deleted_message_type: Literal["RemoveMessage", "RemovedMessage"],
        handle_conversation: bool = True,
        store_message: bool = True,
    ) -> bool:
        """Process shared message logic / پردازش مشترک پیام"""
        if handle_conversation and self.wait_manager and self.wait_manager.auto_track:
            self.wait_manager.track()

        update = Update(message, self)
        is_edited = message["type"] == "UpdatedMessage"
        is_deleted = message["type"] == deleted_message_type

        if handle_conversation and await self._conversation_manager.handle(update, self):
            return True

        for handler_info in handler_infos:
            handler = handler_info["handler"]
            edited_messages_option = handler_info["edited_messages"]
            deleted_messages_option = handler_info["deleted_messages"]

            if edited_messages_option == False and is_edited:
                continue
            elif edited_messages_option == True and not is_edited:
                continue

            if deleted_messages_option == False and is_deleted:
                continue
            elif deleted_messages_option == True and not is_deleted:
                continue

            filters: Filter | None = handler_info["filters"]
            status_filter = await Utils.run_filter(filters, update)
            if not status_filter:
                continue

            self._schedule_handler(handler, update)

        if store_message and not is_edited and not is_deleted:
            if self.enable_stats and self.stats:
                await self.stats.track(update)
            if self.keeper_messages_ram:
                self.messages.append(update)
            if self.keeper_messages_db:
                await self.messages_db.append(update)
        return False

    async def _process_messages_polling(self):
        """Poll updates and monitor Webhook delivery / دریافت Polling و پایش وب‌هوک"""
        while self._running:
            auto_failover_enabled = self._auto_failover_enabled() and bool(self._webhook_server)
            try:
                messages = await self.get_updates(
                    limit=100,
                    offset_id=self.next_offset_id
                )
                updates = messages["updates"]
                self._on_polling_success() if auto_failover_enabled else None
                try:
                    self.next_offset_id = messages["next_offset_id"]
                    if self.save_offset_id:
                        self.session.offset_id = self.next_offset_id
                        await self.session.save()
                except KeyError:
                    pass

                now = time.time()
                for message in updates:
                    if message.get("type") not in ("NewMessage", "UpdatedMessage", "RemoveMessage"):
                        continue
                    # Keep existing Polling behavior: discard updates older than five seconds.
                    try:
                        if not int(message["new_message"]["time"]) + 5 > now:
                            continue
                    except (KeyError, TypeError, ValueError):
                        continue

                    if not self._is_live:
                        await self._process_on_live()
                        self._is_live = True

                    normal_pipeline_ran = bool(self._message_handlers_polling)
                    if normal_pipeline_ran:
                        consumed = await self._process_message_update(
                            message=message,
                            handler_infos=self._message_handlers_polling,
                            deleted_message_type="RemoveMessage",
                        )
                        if consumed:
                            self._remember_conversation_consumed(self._auto_failover_update_key(message))
                    if auto_failover_enabled:
                        await self._queue_or_dispatch_polling_update(message)
                    elif not normal_pipeline_ran:
                        continue
                if auto_failover_enabled:
                    await self._flush_auto_failover_pending()

            except (httpx.ReadError, httpx.ConnectError) as e:
                if auto_failover_enabled:
                    self._on_polling_failure()
                    self.logger.warning(f"Auto Failover monitor: polling network error: {e}")
                else:
                    self.logger.warning(f"خطای شبکه در _process_messages_polling: {e} - انتظار 5 ثانیه...")
                    await asyncio.sleep(5)
            except Exception as e:
                if auto_failover_enabled:
                    self._on_polling_failure()
                self.logger.error(f"خطای ناشناخته در _process_messages_polling: {e}", exc_info=True)

            if auto_failover_enabled:
                await asyncio.sleep(self._auto_failover_check_interval())
            else:
                await asyncio.sleep(self.poll_interval)

    async def _process_webhook_push(self, data: dict, endpoint_type: str):
        """Route Webhook updates to normal and failover handlers / آپدیت وب‌هوک را به هندلرها می‌رساند"""
        updates = data if isinstance(data, list) else [data]
        failover_infos = self._auto_failover_infos()
        # Recovery is counted per Webhook request, not per item in a batch.
        recovering_infos = [
            info for info in failover_infos if info.get("active_source") == "polling"
        ]
        supported_updates = []

        for result in updates:
            if not isinstance(result, dict) or result.get("type") not in (
                "NewMessage", "UpdatedMessage", "RemovedMessage"
            ):
                continue
            supported_updates.append(result)

            normal_pipeline_ran = bool(self._message_handlers_webhook)
            if normal_pipeline_ran:
                consumed = await self._process_message_update(
                    message=result,
                    handler_infos=self._message_handlers_webhook,
                    deleted_message_type="RemovedMessage",
                )
                if consumed:
                    self._remember_conversation_consumed(self._auto_failover_update_key(result))

            # Always accept Webhook deliveries; deduplication rejects anything Polling handled already.
            if failover_infos:
                await self._dispatch_auto_failover_update(
                    result,
                    failover_infos,
                    "webhook",
                    normal_pipeline_ran=normal_pipeline_ran,
                )

        if not supported_updates:
            # An empty/unsupported request does not count as a consecutive recovery success.
            for info in recovering_infos:
                info["_auto_failover_recovery_streak"] = 0
            return

        for info in recovering_infos:
            # Each supported Webhook request advances one consecutive recovery step.
            info["_auto_failover_recovery_streak"] += 1
            required = info["auto_failover_config"]["recovery_successes"]
            if info["_auto_failover_recovery_streak"] >= required:
                info["active_source"] = "webhook"
                info["_auto_failover_recovery_streak"] = 0
                info.get("_auto_failover_pending", {}).clear()
                self.logger.info("Auto Failover: Webhook recovered; switched back to Webhook.")

    async def _process_button_push(self, data: dict):
        """پردازش وب‌هوک Push برای کلیک دکمه‌های اینلاین"""
        updates = data if isinstance(data, list) else [data]
        for result in updates:
            update = UpdateButton(result, self)
            for handler in self._button_handlers:
                filters: InlineFilter | None = handler["filters"]

                status_filter = await Utils.run_filter(
                    filters,
                    update
                )
                if not status_filter:
                    continue
                self._schedule_handler(handler["handler"], update)

    # ═══════════════════════════════════
    # region 🧪 Dry Run | شبیه‌سازی آپدیت
    # ═══════════════════════════════════

    async def _mock_dispatch_message(self, update_data: dict) -> Update:
        """اجرای آپدیت شبیه‌سازی‌شده در خط لولهٔ هندلرها (Dry Run) - برخلاف پولینگ، هندلرها همزمان(await) اجرا می‌شوند تا تست‌ها قطعی باشند"""
        update = Update(update_data, self)
        if self.wait_manager and self.wait_manager.auto_track:
            self.wait_manager.track()

        if await self._conversation_manager.handle(update, self):
            return update

        is_edited = update_data.get("type") == "UpdatedMessage"
        is_deleted = update_data.get("type") in ("RemoveMessage", "RemovedMessage")

        handlers = self._message_handlers_polling + self._message_handlers_webhook + self._message_handlers_failover

        async def _run_handler(upd: Update, _handler):
            try:
                await _handler(upd)
            except Exception as e:
                await self._process_on_error(e=e, update=upd)

        for handler_info in handlers:
            if is_edited and handler_info["edited_messages"] == False:
                continue
            elif (not is_edited) and handler_info["edited_messages"] == True:
                continue
            if is_deleted and handler_info["deleted_messages"] == False:
                continue
            elif (not is_deleted) and handler_info["deleted_messages"] == True:
                continue

            status_filter = await Utils.run_filter(handler_info["filters"], update)
            if not status_filter:
                continue

            middleware = getattr(self, "_middleware_manager", None)
            if middleware is not None and middleware.count > 0:
                await middleware.execute(update, lambda u, _h=handler_info["handler"]: _run_handler(u, _h))
            else:
                await _run_handler(update, handler_info["handler"])

        if not is_edited and not is_deleted:
            if self.enable_stats and self.stats is not None:
                await self.stats.track(update)
            if self.keeper_messages_ram and getattr(self, "messages", None) is not None:
                self.messages.append(update)
            if self.keeper_messages_db and getattr(self, "messages_db", None) is not None:
                await self.messages_db.append(update)
        return update

    async def _mock_dispatch_button(self, data: dict) -> UpdateButton:
        """اجرای کلیک دکمهٔ شبیه‌سازی‌شده در خط لولهٔ هندلرها (Dry Run)"""
        update = UpdateButton(data, self)

        async def _run_handler(upd: UpdateButton, _handler):
            try:
                await _handler(upd)
            except Exception as e:
                await self._process_on_error(e=e, update=upd)

        for handler_info in self._button_handlers:
            status_filter = await Utils.run_filter(handler_info["filters"], update)
            if not status_filter:
                continue

            middleware = getattr(self, "_middleware_manager", None)
            if middleware is not None and middleware.count > 0:
                await middleware.execute(update, lambda u, _h=handler_info["handler"]: _run_handler(u, _h))
            else:
                await _run_handler(update, handler_info["handler"])
        return update

    # endregion

    async def _process_on_start(self):
        for handler in self._on_start_handlers:
            try:
                await handler()
            except Exception as e:
                self.logger.error(f"on_start error : {e}")
    
    async def _process_on_ready(self):
        if self._on_ready_handlers:
            try:
                me = await self.get_me()
                self.logger.info("دکوراتور های on ready با موفقیت در حال اجرا هستند")
                self.logger.info(f"bot info :\n{me}")
                is_ok = True
            except:
                is_ok = False
            if is_ok:
                for handler in self._on_ready_handlers:
                    try:
                        await handler()
                    except Exception as e:
                        self.logger.error(f"on_ready error : {e}")
            else:
                raise httpx.NetworkError("Can't Cannecting To Server BotAPI for GetMe !")

    async def _process_on_run(self):
        for handler in self._on_run_handlers:
            try:
                await handler()
            except Exception as e:
                self.logger.error(f"on_run error : {e}")
    
    async def _process_on_live(self):
        for handler in self._on_live_handlers:
            try:
                await handler()
            except Exception as e:
                self.logger.error(f"on_live error : {e}")

    async def _process_on_error(
        self,
        e: Exception,
        update: Update | UpdateButton | None = None
    ):
        if self._on_error_handlers:
            for handler_info in self._on_error_handlers:
                try:
                    error_handler = handler_info["handler"]
                    type_error = handler_info["error_detail"]
                    if type_error == "full":
                        error = format_exc()
                    elif type_error == "message":
                        error = e
                    elif type_error == "type":
                        error = type(e).__name__
                    else:
                        error = "error invalid input"
                        self.logger.warning(error)
                    await error_handler(error, update)
                except Exception as exc:
                    self.logger.error(f"Error in on_error handler : {exc}")
        else:
            self.logger.error(f"Handler error : {e}", exc_info=True)
    
    async def _process_on_shutdown(self):
        for handler in self._on_shutdown_handlers:
            try:
                await handler()
            except Exception as e:
                self.logger.error(f"on_shutdown error : {e}")

    async def _process_messages_webhook(self):
        while self._running:
            for handler_info in self._webhook_handlers_url:
                url = handler_info["url"]
                response = await self.network.request(
                    url,
                    timeout=self.time_out,
                    type_send="GET"
                )
                result = response.json()
                if isinstance(result, dict) and result and result.get('status') is True and response.status_code == 200:
                    results = result.get('updates', [])
                    if results:
                        for result in results:
                            if result["type"] not in ("NewMessage", "UpdatedMessage", "RemovedMessage"):
                                continue
                            if self.wait_manager and self.wait_manager.auto_track:
                                self.wait_manager.track()
                            update = Update(result, self)
                            if await self._conversation_manager.handle(update, self):
                                continue
                            is_edited = result["type"] == "UpdatedMessage"
                            is_deleted = result["type"] == "RemovedMessage"
                            handler = handler_info["handler"]
                            edited_messages_option = handler_info["edited_messages"]
                            deleted_messages_option = handler_info["deleted_messages"]
                            if edited_messages_option == False and is_edited:
                                continue
                            elif edited_messages_option == True and not is_edited:
                                continue
                            if deleted_messages_option == False and is_deleted:
                                continue
                            elif deleted_messages_option == True and not is_deleted:
                                continue
                            filters: Filter | None = handler_info["filters"]

                            status_filter = await Utils.run_filter(
                                filters,
                                update
                            )
                            if not status_filter:
                                continue
                            self._schedule_handler(handler, update)
                            if not is_edited and not is_deleted:
                                if self.keeper_messages_ram:
                                    self.messages.append(update)
                                if self.keeper_messages_db:
                                    await self.messages_db.append(update)
            await asyncio.sleep(self.poll_interval)

    async def _fetch_button_updates(self):
        while self._running:
            for handler_info in self._button_handlers_url:
                url = handler_info["url"]
                response = await self.network.request(
                    url,
                    timeout=self.time_out,
                    type_send="GET"
                )
                result = response.json()
                if isinstance(result, dict) and result and result.get('status') is True:
                    results = result.get('updates', [])
                    if results:
                        for result in results:
                            update = UpdateButton(result, self)
                            filters: InlineFilter | None = handler_info["filters"]
                        
                            status_filter = await Utils.run_filter(
                                filters,
                                update
                            )
                            if not status_filter:
                                continue
                            self._schedule_handler(handler_info["handler"], update)
            await asyncio.sleep(self.poll_interval)
    
    async def _trigger_before_send(self, **kwargs) -> bool:
        for handler in self._before_send_handlers:
            try:
                result = handler(**kwargs)
                if asyncio.iscoroutine(result):
                    result = await result
                if result is False:
                    return False
            except Exception:
                pass
        return True

    async def _trigger_after_send(self, result: Any, **kwargs):
        kwargs["result"] = result
        for handler in self._after_send_handlers:
            try:
                res = handler(**kwargs)
                if asyncio.iscoroutine(res):
                    await res
            except Exception:
                pass

    async def _process_before_run(self):
        for handler in self._before_run_handlers:
            try:
                result = handler()
                if asyncio.iscoroutine(result):
                    await result
            except Exception as e:
                self.logger.error(f"Error in before_run handler: {e}")

    async def _process_after_run(self):
        for handler in self._after_run_handlers:
            try:
                result = handler()
                if asyncio.iscoroutine(result):
                    await result
            except Exception as e:
                self.logger.error(f"Error in after_run handler: {e}")

    # endregion

    # ═══════════════════════════════════
    # region ⚙️ Utils | متدهای کمکی
    # ═══════════════════════════════════

    async def set_main_parse_mode(
        self,
        parse_mode: Literal['Markdown', 'HTML', 'Null', None]
    ) -> None:
        """setting parse mode main / تنظیم کردن مقدار اصلی پارس مود

توجه :
در صورت تغییر مارکدوان در کلاینت یا متود ست مین پارس مود , پارس مود همیشه روی آن حالت قرار میگیرد
در صورتی که میخواهید از این حالت خارج شود و از ورودی های متود ها پیروی کند مقدار آن را در متود ست مین پارس مود برابر 'Null' کنید"""
        self.main_parse_mode = parse_mode

    async def start_dashboard(
        self,
        host: str = "127.0.0.1",
        port: int = 8080,
        backend: Literal["fastapi", "flask"] = "fastapi",
        path_prefix: str = "/dashboard",
    ) -> str:
        """راه‌اندازی داشبورد HTML آمار پیام‌ها

داشبورد:
    http://{host}:{port}/dashboard
جیسون خام:
    http://{host}:{port}/dashboard/api/stats?sort=count
    sort: count | today | title = count"""
        if not self.enable_stats or self.stats is None:
            raise RuntimeError(
                "برای استفاده از داشبورد، ابتدا `enable_stats=True` را در Client قرار دهید."
            )
        if self._dashboard_task is not None:
            self.logger.warning("داشبورد قبلاً اجرا شده است.")
            return f"http://{host}:{port}{path_prefix}"

        from .dashboard import Dashboard

        self._dashboard = Dashboard(
            client=self,
            host=host,
            port=port,
            backend=backend,
            path_prefix=path_prefix,
            logger=self.logger,
        )
        self._dashboard_task = asyncio.create_task(
            self._dashboard.start(),
            name="fastrub_dashboard",
        )
        url = f"http://{host}:{port}{path_prefix}"
        self.logger.info(f"داشبورد آمار در حال اجرا: {url}")
        return url

    async def start_admin(
        self,
        host: str = "127.0.0.1",
        port: int = 8081,
        backend: Literal["fastapi", "flask"] = "fastapi",
        path_prefix: str = "/admin",
        password: str | None = None,
        session_hours: float = 12.0,
    ) -> str:
        """راه‌اندازی پنل ادمین - لاگ لحظه‌ای، تنظیمات زنده، آمار و ابزارها با احراز هویت داخلی

پنل:
    http://{host}:{port}/admin
اگر password ندهید یک رمز قوی تصادفی ساخته و در کنسول چاپ می‌شود.
پنل به تغییر تنظیمات و ارسال پیام می‌تواند دست بزند - فقط روی شبکهٔ مطمئن بازش کنید."""
        if self._admin_task is not None:
            self.logger.warning("پنل ادمین قبلاً اجرا شده است.")
            return f"http://{host}:{port}{path_prefix}"

        self._admin = AdminPanel(
            client=self,
            host=host,
            port=port,
            backend=backend,
            path_prefix=path_prefix,
            password=password,
            session_hours=session_hours,
            logger=self.logger,
        )
        self._admin_task = asyncio.create_task(
            self._admin.start(),
            name="fastrub_admin",
        )
        url = f"http://{host}:{port}{path_prefix}"
        self.logger.info(f"پنل ادمین در حال اجرا: {url}")
        return url
    
    async def version_botapi(self) -> str:
        """getting version botapi / گرفتن نسخه بات ای پی آی"""
        response = await self.network.request(
            url=self.main_url,
            type_send="GET",
            timeout=self.time_out
        )
        version = response.text
        return version
    
    def add_background_task(
        self,
        coro: Callable,
        *args,
        delay: float = 0.0,
        **kwargs
    ) -> asyncio.Task:
        """add background task / اضافه کردن تسک بک‌گراند"""
        return self._background.add(coro, *args, delay=delay, **kwargs)
    
    async def send_request(
        self,
        method: str,
        data_: dict[str, Any] | None = None
    ) -> dict:
        """ارسال درخواست ها / send request to methods with retry mechanism"""
        return await self.network.send_request(
            method=method,
            data=data_
        )
    
    send_requests = send_request

    def render(
        self,
        template: str,
        auto_escape: bool = True,
        **kwargs
    ) -> tuple[str, list[dict[str, Any]]]:
        return self.template.render(
            template,
            auto_escape=auto_escape,
            **kwargs
        )
    
    @classmethod
    async def from_config(
        cls,
        config: str | dict[str, Any]
    ):
        """ساخت Client از دیکشنری یا فایل JSON."""
        if isinstance(config, str):
            async with aiofiles.open(config, "r") as f:
                content = await f.read()
                config = json.loads(content)
        
        return cls(**config) # type: ignore
        
    # endregion

    # ═══════════════════════════════════
    # region 🔍 Get Message | گرفتن پیام
    # ═══════════════════════════════════

    
    async def get_updates(
        self,
        limit: int | None = None,
        offset_id : str | None = None
    ) -> props:
        """getting messages chats / گرفتن پیام های چت ها"""
        self.logger.debug("get_updates called")
        data = {
            "offset_id": offset_id,
            "limit": limit
        }
        result = await self.network.send_request(
            "getUpdates",
            data,
        )
        return props(result)
    
    
    async def get_message(
        self,
        chat_id: str | None = None,
        message_id: str | None = None,
        limit_search: int = 100,
        search_by: Literal["messages", "get_updates", "all"] = "all",
        max_attempts: int = 10
    ) -> Update | None:
        """get message by id / گرفتن پیام با آیدی"""
        if not message_id:
            raise ValueError("The Message Id not goted .")
        Utils.check_message_id_raise(message_id)
        if chat_id:
            Utils.check_id_raise(chat_id)

        self.logger.debug("get_message called")
        
        if search_by in ("all", "messages"):
            self.logger.info("در حال جستجو پیام در بین پیام های ذخیره شده ...")
            for msg in self.messages:
                if isinstance(msg, Update):
                    if msg.message_id == message_id:
                        if msg.chat_id == chat_id or chat_id is None:
                            self.logger.info("پیام در بین پیام های ذخیره شده پیدا شد !")
                            return msg
            
            if self.keeper_messages_db and chat_id:
                finder = await self.messages_db.find_message(
                    chat_id=chat_id,
                    message_id=message_id
                )
                if finder:
                    self.logger.info("پیام در بین پیام های دیتابیس پیدا شد !")
                    return Update(
                        update_data=finder,
                        client=self
                    )
            self.logger.warning("پیام در بین پیام های ذخیره شده و دیتابیس پیدا نشد !")
        
        if search_by in ("all", "get_updates"):
            self.logger.info("در حال جستجو پیام با get_updates ...")
            attempts = 0
            
            # original_offset = self.next_offset_id_get_message
            
            while attempts < max_attempts:
                attempts += 1
                self.logger.info(f"تلاش {attempts}/{max_attempts}...")
                
                updates = await self.get_updates(limit_search, self.next_offset_id_get_message)
                
                if not updates or "updates" not in updates:
                    break
                
                update_count = len(updates["updates"])
                self.logger.info(f"تعداد پیام‌های دریافتی: {update_count}")
                
                for msg in updates["updates"]:
                    if msg["type"] == "NewMessage":
                        message = Update(msg, self)
                        if message.message_id == message_id:
                            if message.chat_id == chat_id or chat_id is None:
                                self.logger.info("پیام در get_updates پیدا شد !")
                                return message
                
                if update_count < limit_search:
                    self.logger.info("به انتهای پیام‌ها رسیدیم.")
                    break
                
                try:
                    self.next_offset_id_get_message = updates["next_offset_id"]
                except KeyError:
                    break
            
            self.logger.warning(f"پیام در بین get_updates پیدا نشد (بعد از {attempts} تلاش)")
        
        self.logger.error("پیام پیدا نشد !")
        return None

    get_message_by_id = get_message

    
    async def get_messages(
        self,
        chat_id: str,
        message_id: str,
        limit_search: int = 100,
        get_befor: int = 10, # Change to 'get_befor' to 'get_before' in V7
        search_by: Literal["messages", "get_updates", "all"] = "all",
        max_attempts: int = 10
    ) -> list[Update] | None:
        """get messages / گرفتن پیام ها"""
        self.logger.debug("get_messages called")
        Utils.check_id_raise(chat_id)
        Utils.check_message_id_raise(message_id)
        messages = deque(maxlen=get_befor)
        
        if search_by in ("all", "messages"):
            self.logger.info("در حال جستجو پیام در بین پیام های ذخیره شده ...")
            for msg in self.messages:
                if isinstance(msg, Update):
                    messages.append(msg)
                    if msg.message_id == message_id:
                        if msg.chat_id == chat_id or chat_id is None:
                            self.logger.info("پیام ها در بین پیام های ذخیره شده پیدا شد !")
                            return list(messages)
            messages.clear()
            self.logger.warning("پیام ها در بین پیام های ذخیره شده پیدا نشد !")
        
        if search_by in ("all", "get_updates"):
            self.logger.info("در حال جستجو پیام با get_updates ...")
            attempts = 0
            
            while attempts < max_attempts:
                attempts += 1
                self.logger.info(f"تلاش {attempts}/{max_attempts}...")
                
                updates = await self.get_updates(limit_search, self.next_offset_id_get_message)
                
                if not updates or "updates" not in updates:
                    break
                
                update_count = len(updates["updates"])
                
                for msg in updates["updates"]:
                    if msg.get("type") == "NewMessage":
                        message = Update(msg, self)
                        messages.append(message)
                        if message.message_id == message_id:
                            if message.chat_id == chat_id or chat_id is None:
                                self.logger.info("پیام ها در get_updates پیدا شدند !")
                                return list(messages)
                
                if update_count < limit_search:
                    self.logger.info("به انتهای پیام‌ها رسیدیم.")
                    break
                
                try:
                    self.next_offset_id_get_message = updates["next_offset_id"]
                except KeyError:
                    break
            
            self.logger.warning(f"پیام ها در بین get_updates پیدا نشدند (بعد از {attempts} تلاش)")
        
        self.logger.error("پیام ها پیدا نشدند !")
        return None

    get_messages_by_id = get_messages
    get_message_interval = get_messages

    # endregion

    # ═══════════════════════════════════
    # region ⚙️ WebHook Setting | تنظیمات وبهوک
    # ═══════════════════════════════════

    async def set_endpoint(
        self,
        url: str,
        type: Literal[
            "ReceiveUpdate", "GetSelectionItem",
            "ReceiveInlineMessage", "ReceiveQuery",
            "SearchSelectionItems"
        ]
    ) -> props:
        """set endpoint url / تنظیم ادرس اند پوینت"""
        self.logger.debug("set_endpoint called")
        result = await self.network.send_request(
            "updateBotEndpoints",
            {
                "url": url,
                "type": type
            }
        )
        return props(result)
    
    update_end_point = set_endpoint
    update_endpoint = set_endpoint

    async def setup_webhooks(self):
        """خودکار Endpointها رو به روبیکا معرفی می‌کنه (فراخوانی توسط کاربر)"""
        if not self._webhook_server:
            raise RuntimeError("Webhook Server تنظیم نشده. اول webhook=WebhookConfig(...) رو به Client بده.")

        base = self._webhook_server.config.url.rstrip("/")
        prefix = self._webhook_server.config.path_prefix
        
        if self._webhook_server.config.use_token_in_url:
            token = self.token
            endpoints = {
                "ReceiveUpdate": f"{base}{prefix}/message/{token}",
                "ReceiveInlineMessage": f"{base}{prefix}/inline/{token}",
            }
        else:
            endpoints = {
                "ReceiveUpdate": f"{base}{prefix}/message",
                "ReceiveInlineMessage": f"{base}{prefix}/inline",
            }
        
        for endpoint_type, url in endpoints.items():
            await self.update_endpoint(url, endpoint_type) # type: ignore

    # endregion


wrap_all_async_methods(Client)

Robot = Client
Bot = Client
BotApi = Client
BotApiClient = Client
