from random import randint
from ..network import (
    Network,
    Socket
)
from ..crypto import Cryption
from ..utils import Utils
from random import choice
from collections.abc import Callable
from traceback import format_exc
from time import sleep
from ..exceptions import (
    InvalidAuth,
    InvalidInput
)
import asyncio
from typing import Literal

from ...core.async_sync import *
from ...core.background import BackgroundManager
from ...utils.cache import Cache
from ...utils.wait_manager import WaitManager
from ..filters import Filter

from ...utils.text_parser import TextParser
from ...utils.template import TemplateEngine
from ..types import Message

from typing import (
    Any,
    Awaitable,
    Callable,
    Optional,
    ParamSpec,
    TypeVar,
    Concatenate,
    overload
)
import functools

import httpx

P = ParamSpec("P")
R = TypeVar("R")

@overload
def cached(
    func: Callable[Concatenate[Any, P], Awaitable[R]],
) -> Callable[Concatenate[Any, P], Awaitable[R]]: ...

@overload
def cached(
    *,
    cache_key_func: Optional[Callable[Concatenate[Any, P], str]] = None,
) -> Callable[
    [Callable[Concatenate[Any, P], Awaitable[R]]],
    Callable[Concatenate[Any, P], Awaitable[R]],
]: ...

def cached( # pyright: ignore[reportInconsistentOverload]
    func: Optional[Callable[Concatenate[Any, P], Awaitable[R]]] = None,
    *,
    cache_key_func: Optional[Callable[Concatenate[Any, P], str]] = None,
):
    """
    دکوراتور کش با پشتیبانی از دو حالت:
    - @cached
    - @cached(cache_key_func=...)
    """
    def decorator(
        func: Callable[Concatenate[Any, P], Awaitable[R]]
    ) -> Callable[Concatenate[Any, P], Awaitable[R]]:
        @functools.wraps(func)
        async def wrapper(self: Any, *args: P.args, **kwargs: P.kwargs) -> R:
            if self.cache is None:
                return await func(self, *args, **kwargs)

            if cache_key_func is not None:
                key = cache_key_func(self, *args, **kwargs)
            else:
                key = f"{func.__qualname__}:{args}:{kwargs}"

            cached_value = await self.cache.get(key)
            if cached_value is not None:
                return cached_value

            result = await func(self, *args, **kwargs)
            await self.cache.set(key, result)
            return result
        return wrapper

    if func is not None:
        return decorator(func)
    else:
        return decorator

def with_wait(
    channel: Literal[
        "sending", "banning", "forwarding",
        "uploading", "editing", "deleting"
    ] = "sending"
):
    """
    دکوراتور برای اعمال `wait_manager` و `defult_wait` روی متودهای ارسال پیام.

    قبل از اجرای متود، ترافیک را در کانال مشخص ثبت می‌کند و مقدار wait مناسب
    را از WaitManager می‌گیرد و در صورت صفر بودن، از defult_wait استفاده می‌کند.
    """
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(self, *args, **kwargs):
            object_guid = kwargs.get("objectGuid")
            if object_guid is None and args:
                object_guid = args[0]
            await self._wait_send(channel=channel, chat_id=object_guid)
            return await func(self, *args, **kwargs)
        return wrapper
    return decorator

class Methods:
    def __init__(
        self,
        sessionData: dict,
        platform: str,
        apiVersion: int,
        proxy: str | None = None,
        timeOut: int = 30,
        max_retries: int = 5,
        showProgressBar: bool | None = None,
        main_parse_mode: Literal['Markdown', 'HTML', "Null", None] = "Null",
        cache: Cache | None = None,
        max_retries_upload: int | None = None,
        max_retries_download: int | None = None,
        wait_manager: WaitManager | None = None,
        defult_wait: float | None = None,
    ) -> None:
        self.platform = platform.lower()
        if not self.platform in ["android", "web", "rubx", "rubikax", "rubino", "PWA"]:
            raise ValueError(f"The \"{platform}\" is not a valid platform. Choose these one -> (web, android, rubx, PWA)")
        self.apiVersion = apiVersion
        self.proxy = proxy
        self.timeOut = timeOut
        self.showProgressBar = showProgressBar
        self.sessionData = sessionData
        self.main_parse_mode: Literal['Markdown', 'HTML', 'Null', None] = main_parse_mode
        self._background = BackgroundManager()
        self.cache = cache
        self.max_retries_upload = max_retries_upload
        self.max_retries_download = max_retries_download

        self.wait_manager = wait_manager
        self.defult_wait = defult_wait

        self._on_ready_handlers = []
        self._on_start_handlers = []
        self._on_run_handlers = []
        self._on_error_handlers = []
        self._on_live_handlers = []
        # self._on_shutdown_handlers = [] # When add method close
        self._after_run_handlers = []
        self._before_run_handlers = []
        self.crypto = Cryption(
            auth=sessionData["auth"],
            private_key=sessionData["private_key"]
        ) if sessionData else Cryption(auth=Utils.randomTmpSession())
        self.template = TemplateEngine(None)
        self.network = Network(
            methods=self,
            max_retries=max_retries,
            max_retries_upload=max_retries_upload,
            max_retries_download=max_retries_download
        )
        self.socket = Socket(methods=self)


    async def _wait_send(
        self,
        channel: Literal[
            "sending", "banning", "forwarding",
            "uploading", "editing", "deleting"
        ] = "sending",
        chat_id: str | None = None,
        wait_send: float | None = None,
    ) -> None:
        """
        اعمال wait_manager و defult_wait قبل از ارسال درخواست.

        اولویت انتخاب مقدار انتظار:
          1. `wait_send` اگر صریح داده شده باشد
          2. `wait_manager.get_time(channel, chat_id)`
          3. `defult_wait`

        منطق `track_after_send`: اگر در WaitManager فعال باشد، قبل از wait
        یک واحد ترافیک در کانال مربوطه ثبت می‌شود (مشابه کلاینت ربات).

        `auto_track` را در یوزربات نمی‌توان خودکار کرد چون هیچ حلقهٔ پولینگی
        وجود ندارد؛ کاربر باید دستی `wait_manager.track()` صدا بزند.
        """
        if wait_send is None:
            if self.wait_manager:
                if self.wait_manager.track_after_send:
                    _chat_id = chat_id if self.wait_manager.per_chat else None
                    self.wait_manager.add_traffic(channel=channel, chat_id=_chat_id)
                wait_send = await self.wait_manager.get_time(
                    channel=channel,
                    chat_id=chat_id,
                )
            if not wait_send:
                wait_send = self.defult_wait

        if wait_send and wait_send > 0:
            await asyncio.sleep(wait_send)

    # Authentication methods

    async def _parse_mode_text(
        self,
        text: str,
        parse_mode: Literal["Markdown","HTML","Null",None] = "Markdown"
    ) -> tuple[list[dict[str, Any]], str]:
        """setting parse mode text / تنظیم پارس مود متن"""
        if self.main_parse_mode != "Null":
            parse_mode = self.main_parse_mode
        if parse_mode == "Markdown":
            data = TextParser.markdown(text)
            return data
        elif parse_mode == "HTML":
            data = TextParser.html(text)
            return data
        return [], text

    async def _prepare_text(
        self,
        text: str,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        context: dict[str, Any] | None = None,
        auto_escape: bool = True,
    ) -> tuple[list[dict[str, Any]], str]:
        """آماده‌سازی متن پیام: قالب {{ }} با محافظت تزریق + پارس مود - خروجی (metadata, text)

        با context، مارک‌داونِ خودِ قالب فعال می‌ماند ولی مقادیر context خنثی می‌شوند
        (auto_escape=True) یا آزادانه پارس می‌شوند (auto_escape=False).
        """
        if self.main_parse_mode != "Null":
            parse_mode = self.main_parse_mode
        if context:
            clean_text, metadata = self.template.render(
                text,
                parse_mode=parse_mode,
                auto_escape=auto_escape,
                **context
            )
            return metadata, clean_text
        return await self._parse_mode_text(text, parse_mode)

    def render(
        self,
        template: str,
        auto_escape: bool = True,
        **kwargs: Any
    ) -> tuple[str, list[dict[str, Any]]]:
        """رندر قالب {{ placeholder }} - خروجی (text, metadata)"""
        return self.template.render(template, auto_escape=auto_escape, **kwargs)

    async def set_main_parse_mode(
        self,
        parse_mode: Literal['Markdown', 'HTML', 'Null', None]
    ) -> None:
        """setting parse mode main / تنظیم کردن مقدار اصلی پارس مود"""
        self.main_parse_mode = parse_mode


    def add_background_task(
        self,
        coro: Callable,
        *args,
        delay: float = 0.0,
        **kwargs
    ) -> asyncio.Task:
        """add background task / اضافه کردن تسک بک‌گراند"""
        return self._background.add(coro, *args, delay=delay, **kwargs)



    async def sendCode(self, phoneNumber: str, passKey: str | None = None, sendInternal: bool = False) -> dict:
        input:dict = {
            "phone_number": f"{Utils.phone_number_parse(phoneNumber)}",
            "send_type": "Internal" if sendInternal else "SMS",
        }

        if passKey:
            input["pass_key"] = passKey

        return await self.network.request(
            method="sendCode",
            input=input,
            tmpSession=True
        )


    async def signIn(self, phoneNumber, phoneCodeHash, phoneCode) -> dict:
        publicKey, privateKey = self.crypto.rsaKeyGenrate()

        data = await self.network.request(
            method="signIn",
            input={
                "phone_number": Utils.phone_number_parse(phoneNumber),
                "phone_code_hash": phoneCodeHash,
                "phone_code": phoneCode,
                "public_key": publicKey
            },
            tmpSession=True
        )

        data["private_key"] = privateKey

        return data


    async def registerDevice(self, deviceModel) -> dict:
        return await self.network.request(
            method="registerDevice",
            input={
                "app_version": "WB_4.3.3" if self.platform == "web" else "MA_3.4.3",
                "device_hash": Utils.randomDeviceHash(),
                "device_model": deviceModel,
                "is_multi_account": False,
                "lang_code": "fa",
                "system_version": "Windows 11" if self.platform == "web" else "SDK 28",
                "token": "",
                "token_type": "Web" if self.platform == "web" else "Firebase"
            }
        )


    async def logout(self) -> dict:
        return await self.network.request(method="logout")

    # Chats methods


    @cached(cache_key_func=lambda self, startId: f"getChats:{startId}")
    async def getChats(self, startId:str | None) -> dict:
        return await self.network.request(method="getChats", input={"start_id": startId})


    @cached(cache_key_func=lambda self, username: f"username:{username.replace('@', '')}")
    async def getObjectByUsername(self, username: str) -> dict:
        username = username.replace("@", "")
        return await self.network.request(method="getObjectByUsername",input={'username': username})


    @cached
    async def getTopChatUsers(self) -> dict:
        return await self.network.request(method="getTopChatUsers")


    async def removeFromTopChatUsers(self, objectGuid:str) -> dict:
        return await self.network.request(method="removeFromTopChatUsers", input={"user_guid": objectGuid})


    @cached
    async def getChatAds(self) -> dict:
        return await self.network.request(method="getChatAds", input={"state": Utils.getState()})


    async def getChatsUpdates(self) -> dict:
        return await self.network.request(method="getChatsUpdates", input={"state": Utils.getState()})


    async def joinChat(self, guidOrLink:str) -> dict:
        if Utils.checkLink(guidOrLink):
            method:str = "joinGroup" if Utils.getChatTypeByLink(link=guidOrLink) == "Group" else "joinChannelByLink"
        else:
            method:str = "joinChannelAction"

        return await self.network.request(
            method=method,
            input={"hash_link": guidOrLink.split("/")[-1]} if Utils.checkLink(guidOrLink) else {
                "channel_guid": guidOrLink,
                "action": "Join"
            }
        )


    async def actionOnJoinRequest(self,objectGuid: str, userGuid: str, action: Literal["Accept", "Reject"]):
        object_type = Utils.getChatTypeByGuid(objectGuid)
        return await self.network.request(
            method="actionOnJoinRequest",
            input={
                "object_guid": objectGuid,
                "object_type": object_type,
                "user_guid": userGuid,
                "action": action
            }
        )


    @cached(cache_key_func=lambda self, objectGuid: f"getJoinRequests:{objectGuid}")
    async def getJoinRequests(self, objectGuid: str):
        return await self.network.request(
            method="getJoinRequests",
            input={
                "object_guid": objectGuid
            }
        )


    async def leaveChat(self, objectGuid:str) -> dict:
        input: dict = {f"{Utils.getChatTypeByGuid(objectGuid=objectGuid).lower()}_guid": objectGuid}

        if Utils.getChatTypeByGuid(objectGuid=objectGuid) == "Group": method:str = "leaveGroup"
        else:
            method:str = "joinChannelAction"
            input["action"] = "Leave"

        return await self.network.request(
            method=method,
            input=input
        )


    async def removeChat(self, objectGuid:str) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"remove{chatType}",
            input={f"{chatType.lower()}_guid": objectGuid}
        )


    @cached(cache_key_func=lambda self, objectGuid: f"getChatInfo:{objectGuid}")
    async def getChatInfo(self, objectGuid:str) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"get{chatType}Info",
            input={f"{chatType.lower()}_guid": objectGuid}
        )


    @cached(cache_key_func=lambda self, username: f"getChatInfoByUsername:{username.replace('@', '')}")
    async def getChatInfoByUsername(
        self,
        username: str
    ) -> dict:
        username = username.replace("@", "")
        return await self.network.request(method="getObjectInfoByUsername", input={"username": username})


    @cached(cache_key_func=lambda self, objectGuid: f"getChatLink:{objectGuid}")
    async def getChatLink(self, objectGuid:str) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"get{chatType}Link",
            input={f"{chatType.lower()}_guid": objectGuid}
        )


    async def setChatLink(
        self,
        objectGuid: str
    ) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"set{chatType}Link",
            input={f"{chatType.lower()}_guid": objectGuid}
        )


    async def setChatAdmin(self, objectGuid:str, memberGuid:str, accessList:list | None, customTitle:str | None, action:str) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        input:dict = {
            f"{chatType.lower()}_guid": objectGuid,
            "member_guid": memberGuid,
            "action": action,
            "access_list": accessList or []
        }

        if customTitle: input["custom_title"] = customTitle

        return await self.network.request(
            method=f"set{chatType}Admin",
            input=input
        )


    async def addChatMember(self, objectGuid:str, memberGuids:list) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"add{chatType}Members",
            input={
                f"{chatType.lower()}_guid": objectGuid,
                "member_guids": memberGuids
            }
        )


    @with_wait("banning")
    async def banChatMember(self, objectGuid:str, memberGuid:str, action:str) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"ban{chatType}Member",
            input={
                f"{chatType.lower()}_guid": objectGuid,
                "member_guid": memberGuid,
                "action": action
            }
        )


    @cached(cache_key_func=lambda self, objectGuid, startId: f"getBannedChatMembers:{objectGuid}:{startId}")
    async def getBannedChatMembers(
        self,
        objectGuid: str,
        startId: str | None
    ) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"getBanned{chatType}Members",
            input={
                f"{chatType.lower()}_guid": objectGuid,
                "start_id": startId
            }
        )


    @cached(cache_key_func=lambda self, objectGuid, searchText, startId: f"getChatAllMembers:{objectGuid}:{searchText}:{startId}")
    async def _getChatAllMembersData(self, objectGuid: str, searchText: str | None, startId: str | None) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"get{chatType}AllMembers",
            input={
                f"{chatType.lower()}_guid": objectGuid,
                "search_text": searchText.replace("@", "") if searchText else searchText,
                "start_id": startId
            }
        )

    async def getChatAllMembers(
        self,
        objectGuid: str,
        searchText: str | None,
        startId: str | None,
        justGetGuids: bool = False
    ) -> dict |list:
        data = await self._getChatAllMembersData(objectGuid, searchText, startId)
        if justGetGuids:
            return [i["member_guid"] for i in data["in_chat_members"]]
        return data


    @cached(cache_key_func=lambda self, objectGuid, startId: f"getChatAdminMembers:{objectGuid}:{startId}")
    async def _getChatAdminMembersData(self, objectGuid: str, startId: str | None) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"get{chatType}AdminMembers",
            input={
                f"{chatType.lower()}_guid": objectGuid,
                "start_id": startId
            }
        )

    async def getChatAdminMembers(
        self,
        objectGuid: str,
        startId: str | None,
        justGetGuids: bool = False
    ) -> dict |list:
        data = await self._getChatAdminMembersData(objectGuid, startId)
        if justGetGuids:
            return [i["member_guid"] for i in data["in_chat_members"]]
        return data


    @cached(cache_key_func=lambda self, objectGuid, userGuid: f"userIsAdmin:{objectGuid}:{userGuid}")
    async def userIsAdmin(
        self,
        objectGuid: str,
        userGuid: str
    ):
        nextStartId = None
        hasContinue = True
        while hasContinue:
            result = await self.getChatAdminMembers(objectGuid, nextStartId)
            if type(result) is dict: # for typing error
                hasContinue = result["has_continue"]
                nextStartId = result["next_start_id"]
                for user in result["in_chat_members"]:
                    if userGuid == user.member_guid:
                        return True
        return False


    @cached(cache_key_func=lambda self, objectGuid, memberGuid: f"getChatAdminAccessList:{objectGuid}:{memberGuid}")
    async def getChatAdminAccessList(
        self,
        objectGuid: str,
        memberGuid: str
    ) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"get{chatType}AdminAccessList",
            input={
                f"{chatType.lower()}_guid": objectGuid,
                "member_guid": memberGuid
            }
        )


    @cached(cache_key_func=lambda self, link: f"chatPreviewByJoinLink:{link}")
    async def chatPreviewByJoinLink(
        self,
        link: str
    ) -> dict:
        return await self.network.request(
            method="groupPreviewByJoinLink" if "joing" in link else "channelPreviewByJoinLink",
            input={"hash_link": link.split("/")[-1]}
        )


    async def createChatVoiceChat(self, objectGuid:str) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"create{chatType}VoiceChat",
            input={f"{chatType.lower()}_guid": objectGuid}
        )


    async def joinVoiceChat(self, objectGuid:str, myGuid:str, voiceChatId:str, sdp_offer_data:str) -> dict:
        return await self.network.request(
            method=f"join{Utils.getChatTypeByGuid(objectGuid=objectGuid)}VoiceChat",
            input={
                "chat_guid": objectGuid,
                "voice_chat_id": voiceChatId,
                "sdp_offer_data": sdp_offer_data,
                "self_object_guid": myGuid
            }
        )


    async def setChatVoiceChatSetting(self, objectGuid:str, voideChatId:str, title:str | None, joinMuted:bool | None) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        input = {
            f"{chatType.lower()}_guid": objectGuid,
            "voice_chat_id": voideChatId,
            "updated_parameters": []
        }

        if title:
            input["title"] = title
            input["updated_parameters"].append("title")

        if joinMuted:
            input["join_muted"] = joinMuted
            input["updated_parameters"].append("join_muted")

        return await self.network.request(
            method=f"set{chatType}VoiceChatSetting",
            input=input
        )


    async def getChatVoiceChatUpdates(self, objectGuid:str, voideChatId:str) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"get{chatType}VoiceChatUpdates",
            input={
                f"{chatType.lower()}_guid": objectGuid,
                "voice_chat_id": voideChatId,
                "state": Utils.getState()
            }
        )


    async def getChatVoiceChatParticipants(self, objectGuid:str, voideChatId:str) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"get{chatType}VoiceChatParticipants",
            input={
                f"{chatType.lower()}_guid": objectGuid,
                "voice_chat_id": voideChatId,
            }
        )


    async def setChatVoiceChatState(self, objectGuid:str, voideChatId:str, activity:str, participantObjectGuid:str) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"set{chatType}VoiceChatState",
            input={
                "chat_guid": objectGuid,
                "voice_chat_id": voideChatId,
                "action": activity,
                "participant_object_guid": participantObjectGuid
            }
        )


    async def sendChatVoiceChatActivity(self, objectGuid:str, voideChatId:str, activity:str, participantObjectGuid:str) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"send{chatType}VoiceChatActivity",
            input={
                "chat_guid": objectGuid,
                "voice_chat_id": voideChatId,
                "activity": activity,
                "participant_object_guid": participantObjectGuid
            }
        )


    async def leaveChatVoiceChat(self, objectGuid:str, voideChatId:str) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"leave{chatType}VoiceChat",
            input={
                f"{chatType.lower()}_guid": objectGuid,
                "voice_chat_id": voideChatId
            }
        )


    async def discardChatVoiceChat(self, objectGuid:str, voideChatId:str) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"discard{chatType}VoiceChat",
            input={
                f"{chatType.lower()}_guid": objectGuid,
                "voice_chat_id": voideChatId
            }
        )


    async def setActionChat(self, objectGuid:str, action:str) -> dict:
        return await self.network.request(
            method="setActionChat",
            input={
                "object_guid": objectGuid,
                "action": action
            }
        )


    async def seenChats(self, seenList:dict) -> dict:
        return await self.network.request(method="seenChats", input={"seen_list": seenList})


    async def seenChatMessages(self, objectGuid:str, minId:str, maxId:str) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"seen{chatType}Messages",
            input={
                f"{chatType.lower()}_guid": objectGuid,
                "min_id": minId,
                "max_id": maxId
            }
        )


    async def sendChatActivity(self, objectGuid:str, activity:str) -> dict:
        return await self.network.request(
            method="sendChatActivity",
            input={
                "object_guid": objectGuid,
                "activity": activity
            }
        )


    @cached(cache_key_func=lambda self, objectGuid, searchText: f"searchChatMessages:{objectGuid}:{searchText}")
    async def searchChatMessages(
        self,
        objectGuid: str,
        searchText: str
    ) -> dict:
        return await self.network.request(
            method="searchChatMessages",
            input={
                "object_guid": objectGuid,
                "search_text": searchText,
                "type": "Hashtag" if searchText.startswith("#") else "Text"
            }
        )


    async def uploadAvatar(
        self,
        objectGuid: str,
        mainFile: str,
        thumbnailFile: str | None
    ) -> dict | None:
        uploadMainFileData = await self.network.upload(file=mainFile)

        if uploadMainFileData is not None and thumbnailFile is not None:
            uplo_ = await self.network.upload(file=thumbnailFile)
            if isinstance(uplo_,dict):
                return await self.network.request(
                    method="uploadAvatar",
                    input={
                        "object_guid": objectGuid,
                        "thumbnail_file_id": uplo_["id"] if thumbnailFile else uploadMainFileData["id"],
                        "main_file_id": uploadMainFileData["id"]
                    }
                )
        raise ValueError("Error ! Value invalid")


    @cached(cache_key_func=lambda self, objectGuid: f"getAvatars:{objectGuid}")
    async def getAvatars(self, objectGuid:str) -> dict:
        return await self.network.request(method="getAvatars", input={"object_guid": objectGuid})


    async def deleteAvatar(self, objectGuid:str, avatarId:str) -> dict:
        return await self.network.request(
            method="deleteAvatar",
            input={
                "object_guid": objectGuid,
                "avatar_id": avatarId
            }
        )


    async def deleteChatHistory(self, objectGuid:str, lastMessageId:str) -> dict:
        return await self.network.request(
            method="deleteChatHistory",
            input={
                "object_guid": objectGuid,
                "last_message_id": lastMessageId
            }
        )


    async def deleteUserChat(self, userGuid:str, lastDeletedMessageId) -> dict:
        return await self.network.request(
            method="deleteUserChat",
            input={
                "user_guid": userGuid,
                "last_deleted_message_id": lastDeletedMessageId
            }
        )


    @cached(cache_key_func=lambda self, objectGuid: f"getPendingObjectOwner:{objectGuid}")
    async def getPendingObjectOwner(
        self,
        objectGuid: str
    ) -> dict:
        return await self.network.request(
            method="getPendingObjectOwner",
            input={
                "object_guid": objectGuid
            }
        )


    async def requestChangeObjectOwner(
        self,
        objectGuid: str,
        memberGuid: str
    ) -> dict:
        return await self.network.request(
            method="requestChangeObjectOwner",
            input={
                "new_owner_user_guid": memberGuid,
                "object_guid": objectGuid
            }
        )


    async def replyRequestObjectOwner(self, objectGuid:str, action:str) -> dict:
        return await self.network.request(
            method="replyRequestObjectOwner",
            input={
                "action": action, #Accept Reject
                "object_guid": objectGuid
            }
        )


    async def cancelChangeObjectOwner(self, objectGuid:str) -> dict:
        return await self.network.request(method="cancelChangeObjectOwner", input={"object_guid": objectGuid})


    @cached(cache_key_func=lambda self, objectGuid, minId, maxId: f"getChatReaction:{objectGuid}:{minId}:{maxId}")
    async def getChatReaction(self, objectGuid:str, minId:str, maxId:str) -> dict:
        return await self.network.request(
            method="getChatReaction",
            input={
                f"object_guid": objectGuid,
                "min_id": minId,
                "max_id": maxId
            }
        )


    async def reportObject(self, objectGuid:str, description:str) -> dict:
        return await self.network.request(
            method="reportObject",
            input={
                "object_guid": objectGuid,
                "report_description": description,
                "report_type": 100,
                "report_type_object": "Object"
            }
        )


    async def setChatUseTime(self, objectGuid:str, time:int) -> dict:
        return await self.network.request(
            method="setChatUseTime",
            input={
                "object_guid": objectGuid,
                "time": time
            }
        )

    # User methods


    async def setBlockUser(self, objectGuid:str, action:str) -> dict:
        return await self.network.request(
            method="setBlockUser",
            input={
                "user_guid": objectGuid,
                "action": action
            }
        )


    async def checkUserUsername(self, username:str) -> dict:
        return await self.network.request(
            method="checkUserUsername",
            input={
                "username": username,
            }
        )

    # Group methods


    async def addGroup(self, title:str, memberGuids:list) -> dict:
        return await self.network.request(
            method="addGroup",
            input={
                "title": title,
                "member_guids": memberGuids
            }
        )


    @cached(cache_key_func=lambda self, objectGuid: f"getGroupDefaultAccess:{objectGuid}")
    async def getGroupDefaultAccess(
        self,
        objectGuid: str
    ) -> dict:
        return await self.network.request(
            method=f"getGroupDefaultAccess",
            input={"group_guid": objectGuid}
        )


    async def setChatDefaultAccess(
        self,
        objectGuid: str,
        accessList: list
    ) -> dict:
        chatType = Utils.getChatTypeByGuid(objectGuid=objectGuid)

        return await self.network.request(
            method=f"set{chatType}DefaultAccess",
            input={
                f"group_guid": objectGuid,
                "access_list": accessList
            }
        )


    @cached(cache_key_func=lambda self, objectGuid, searchMention: f"getGroupMentionList:{objectGuid}:{searchMention}")
    async def getGroupMentionList(
        self,
        objectGuid: str,
        searchMention: str
    ) -> dict:
        return await self.network.request(
            method="getGroupMentionList",
            input={
                "group_guid": objectGuid,
                "search_mention": searchMention
            }
        )


    async def editGroupInfo(
        self,
        objectGuid:str,
        title:str | None,
        description:str | None,
        slowMode:int | None,
        eventMessages:bool | None,
        chatHistoryForNewMembers:bool | None,
        reactionType:str | None, #Selected Disabled All
        selectedReactions:list[str] | None
    ) -> dict:

        input = {
            "group_guid": objectGuid,
            "updated_parameters": []
        }

        if title:
            input["title"] = title
            input["updated_parameters"].append("title")

        if description:
            input["description"] = description
            input["updated_parameters"].append("description")

        if slowMode:
            input["slow_mode"] = slowMode
            input["updated_parameters"].append("slow_mode")

        if not eventMessages is None:
            input["event_messages"] = eventMessages
            input["updated_parameters"].append("event_messages")

        if not chatHistoryForNewMembers is None:
            input["chat_history_for_new_members"] = "Visible" if chatHistoryForNewMembers else "Hidden"
            input["updated_parameters"].append("chat_history_for_new_members")

        if reactionType:
            if selectedReactions:
                input["chat_reaction_setting"] = {"reaction_type": reactionType,"selected_reactions":selectedReactions}
            else:
                input["chat_reaction_setting"] = {"reaction_type": reactionType}
            input["updated_parameters"].append("chat_reaction_setting")


        return await self.network.request(
            method="editGroupInfo",
            input=input
        )

    # Channel methods


    async def addChannel(self, title:str, description:str | None, memberGuids:list | None, private:bool) -> dict:
        input = {
            "title": title,
            "description": description,
            "member_guids": memberGuids or [],
            "channel_type": "Private" if private else "Public"
        }

        return await self.network.request(
            method="addChannel",
            input=input
        )


    async def editChannelInfo(
        self,
        objectGuid:str,
        title:str | None,
        description:str | None,
        username:str | None,
        private:bool | None,
        signMessages:bool | None,
        reactionType:str | None, #Selected Disabled All
        selectedReactions:list | None
    ) -> dict:

        input:dict = {
            "channel_guid": objectGuid,
            "updated_parameters": []
        }

        if selectedReactions: input["chat_reaction_setting"]["selected_reactions"] = selectedReactions

        if title:
            input["title"] = title
            input["updated_parameters"].append("title")

        if description:
            input["description"] = description
            input["updated_parameters"].append("description")

        if not private is None:
            input["channel_type"] = "Private" if private else "Public"
            input["updated_parameters"].append("channel_type")

        if not signMessages is None:
            input["sign_messages"] = signMessages
            input["updated_parameters"].append("sign_messages")

        if reactionType:
            if selectedReactions:
                input["chat_reaction_setting"] = {"reaction_type": reactionType,"selected_reactions":selectedReactions}
            else:
                input["chat_reaction_setting"] = {"reaction_type": reactionType}
            input["updated_parameters"].append("chat_reaction_setting")

        if username:
            await self.updateChannelUsername(
                objectGuid=objectGuid,
                username=username
            )

        return await self.network.request(
            method="editChannelInfo",
            input=input
        )


    async def checkChannelUsername(self, username:str) -> dict:
        return await self.network.request(
            method="checkChannelUsername",
            input={
                "username": username,
            }
        )


    async def updateChannelUsername(self, objectGuid:str, username:str) -> dict:
        return await self.network.request(
            method="updateChannelUsername",
            input={
                "channel_guid": objectGuid,
                "username": username
            }
        )


    @cached(cache_key_func=lambda self, objectGuid, minId, maxId: f"getChannelSeenCount:{objectGuid}:{minId}:{maxId}")
    async def getChannelSeenCount(
        self,
        objectGuid: str,
        minId: str,
        maxId: str
    ) -> dict:
        return await self.network.request(
            method="getChannelSeenCount",
            input={
                "channel_guid": objectGuid,
                "min_id": minId,
                "max_id": maxId
            }
        )

    # Message methods

    @with_wait("sending")
    async def sendText(
        self,
        objectGuid: str,
        text: str,
        messageId: str | None,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        context: dict[str, Any] | None = None,
        auto_escape: bool = True
    ) -> dict:
        metadata, text = await self._prepare_text(text, parse_mode, context, auto_escape)

        input = {
            "object_guid": objectGuid,
            "rnd": str(randint(10000000, 999999999)),
            "text": text,
            "reply_to_message_id": messageId,
        }

        if metadata != []: input["metadata"] = {"meta_data_parts": metadata}

        return await self.network.request(method="sendMessage", input=input)




    async def sendMessage(
        self,
        objectGuid: str,
        text: str | None = None,
        mesageId: str | None = None,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        # file
        file: str | None = None,
        fileName: str | None = None,
        typeFile: Literal["Image", "Video", "Gif", "VideoMessage","Music", "Voice","File"] = "File",
        isSpoil: bool = False,
        customThumbInline: str | None = None,
        time: int | None = None,
        performer: str | None = None,
        # poll
        question: str | None = None,
        options: list | None = None,
        typePoll: Literal["Regular", "Quiz"] = "Regular",
        isAnonymous: bool = True,
        correctOptionIndex: int | None = None,
        allowsMultipleAnswers: bool = False,
        hint: str | None = None,
        # location
        latitude: int | None = None,
        longitude: int | None = None,
        # contact
        firstName: str | None = None,
        lastName: str | None = None,
        phoneNumber: str | None = None,
        userGuid: str | None = None,
        context: dict[str, Any] | None = None,
        auto_escape: bool = True
    ) -> dict | None:
        if file:
            return await self.baseSendFileInline(
                objectGuid=objectGuid,
                file=file,
                text=text,
                messageId=mesageId,
                fileName=fileName,
                type=typeFile,
                isSpoil=isSpoil,
                customThumbInline=customThumbInline,
                time=time,
                performer=performer,
                parse_mode=parse_mode,
                context=context,
                auto_escape=auto_escape
            )
        elif (not question is None) and (not options is None):
            return await self.sendPoll(
                objectGuid=objectGuid,
                question=question,
                options=options,
                allowsMultipleResponses=allowsMultipleAnswers,
                isAnonymous=isAnonymous,
                type=typePoll,
                messageId=mesageId,
                correctOptionIndex=correctOptionIndex,
                hint=hint
            )
        elif (not latitude is None) and (not longitude is None):
            return await self.sendLocation(
                objectGuid=objectGuid,
                latitude=latitude,
                longitude=longitude,
                messageId=mesageId
            )
        elif firstName and lastName and phoneNumber and userGuid:
            return await self.sendContact(
                objectGuid=objectGuid,
                firstName=firstName,
                lastName=lastName,
                phoneNumber=phoneNumber,
                messageId=mesageId,
                userGuid=userGuid
            )
        elif not text is None:
            return await self.sendText(
                objectGuid=objectGuid,
                text=text,
                messageId=mesageId,
                parse_mode=parse_mode,
                context=context,
                auto_escape=auto_escape
            )
        raise ValueError("Please Write The Args !")


    @with_wait("sending")
    async def baseSendFileInline(
        self,
        objectGuid: str,
        file: str,
        text: str | None = None,
        messageId: str | None = None,
        fileName: str | None = None,
        type: Literal["Image", "Video", "Gif", "VideoMessage","Music", "Voice","File"] = "File",
        isSpoil: bool = False,
        customThumbInline: str | None = None,
        time: int | None = None,
        performer: str | None = None,
        show_progress_bar: bool = False,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        context: dict[str, Any] | None = None,
        auto_escape: bool = True
    ) -> dict | None:
        upload_data = await self.network.upload(
            file=file,
            fileName=fileName,
            show_progress_bar=show_progress_bar
        )
        if isinstance(upload_data,dict):
            uploadData:dict = dict(upload_data)
            if not uploadData:
                return

            input:dict = {
                "file_inline": {
                    "dc_id": uploadData["dc_id"],
                    "file_id": uploadData["id"],
                    "file_name": uploadData["file_name"],
                    "size": uploadData["size"],
                    "mime": uploadData["mime"],
                    "access_hash_rec": uploadData["access_hash_rec"],
                    "type": type,
                    "is_spoil": isSpoil
                },
                "object_guid": objectGuid,
                "rnd": Utils.randomRnd(),
                "reply_to_message_id": messageId
            }

            if type in ["Image", "Video", "Gif", "VideoMessage"]:
                customThumbInline = Utils.getImageThumbnail(
                    customThumbInline
                    if isinstance(customThumbInline, bytes)
                    else (await self.network._client.request("GET", customThumbInline)).content # pyright: ignore[reportOptionalMemberAccess]
                    if Utils.checkLink(customThumbInline)
                    else open(customThumbInline, "rb").read()
                ) if customThumbInline else None

                videoData=[]
                if not type == "Image":
                    videoData:list = list(Utils.getVideoData(uploadData["file"]))
                    input["file_inline"]["time"] = videoData[2] * 1000

                fileSize:list = list(Utils.getImageSize(uploadData["file"])) if type == "Image" else videoData[1]
                input["file_inline"]["width"] = fileSize[0]
                input["file_inline"]["height"] = fileSize[1]

                if type == "VideoMessage":
                    input["file_inline"]["type"] = "Video"
                    input["file_inline"]["is_round"] = True

                input["file_inline"]["thumb_inline"] = customThumbInline or (Utils.getImageThumbnail(uploadData["file"]) if type == "Image" else videoData[0])

            if type in ["Music", "Voice"]:
                input["file_inline"]["time"] = (time or Utils.getVoiceDuration(uploadData["file"])) * (1000 if type == "Voice" else 1)

                if type == "Music":
                    input["file_inline"]["music_performer"] = performer or Utils.getMusicArtist(uploadData["file"])


            if text:
                metadata, _text = await self._prepare_text(text, parse_mode, context, auto_escape)
                input["text"] = _text
                if metadata:
                    input["metadata"] = {"meta_data_parts": metadata}

            return await self.network.request(
                method="sendMessage",
                input=input
            )



    async def sendFile(
        self,
        objectGuid: str,
        file: str,
        messageId: str | None,
        text: str | None,
        fileName: str | None = None,
        show_progress_bar: bool = False,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        context: dict[str, Any] | None = None,
        auto_escape: bool = True
    ) -> dict | None:
        if fileName is None:
            fileName = Utils.format_file("File")
        return await self.baseSendFileInline(
            objectGuid=objectGuid,
            file=file,
            text=text,
            messageId=messageId,
            fileName=fileName,
            type="File",
            show_progress_bar=show_progress_bar,
            parse_mode=parse_mode,
            context=context,
            auto_escape=auto_escape
        )


    async def sendImage(
        self,
        objectGuid: str,
        file: str,
        messageId: str | None,
        text: str | None,
        isSpoil: bool,
        thumbInline: str | None,
        fileName: str | None = None,
        show_progress_bar: bool = False,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        context: dict[str, Any] | None = None,
        auto_escape: bool = True
    ) -> dict | None:
        if fileName is None:
            fileName = Utils.format_file("Image")
        return await self.baseSendFileInline(
            objectGuid=objectGuid,
            file=file,
            text=text,
            messageId=messageId,
            fileName=fileName,
            type="Image",
            isSpoil=isSpoil,
            customThumbInline=thumbInline,
            show_progress_bar=show_progress_bar,
            parse_mode=parse_mode,
            context=context,
            auto_escape=auto_escape
        )


    async def sendVideo(
        self,
        objectGuid: str,
        file: str,
        messageId: str | None,
        text: str | None,
        isSpoil: bool,
        thumbInline: str | None,
        fileName: str | None = None,
        show_progress_bar: bool = False,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        context: dict[str, Any] | None = None,
        auto_escape: bool = True
    ) -> dict | None:
        if fileName is None:
            fileName = Utils.format_file("Video")
        return await self.baseSendFileInline(
            objectGuid=objectGuid,
            file=file,
            text=text,
            messageId=messageId,
            fileName=fileName,
            type="Video",
            isSpoil=isSpoil,
            customThumbInline=thumbInline,
            show_progress_bar=show_progress_bar,
            parse_mode=parse_mode,
            context=context,
            auto_escape=auto_escape
        )


    async def sendVideoMessage(
        self,
        objectGuid: str,
        file: str,
        messageId: str | None,
        text: str | None,
        thumbInline: str | None,
        fileName: str | None = None,
        show_progress_bar: bool = False,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        context: dict[str, Any] | None = None,
        auto_escape: bool = True
    ) -> dict | None:
        if fileName is None:
            fileName = Utils.format_file("Video")
        return await self.baseSendFileInline(
            objectGuid=objectGuid,
            file=file,
            text=text,
            messageId=messageId,
            fileName=fileName,
            type="VideoMessage",
            customThumbInline=thumbInline,
            show_progress_bar=show_progress_bar,
            parse_mode=parse_mode,
            context=context,
            auto_escape=auto_escape
        )


    async def sendGif(
        self,
        objectGuid: str,
        file: str,
        messageId: str | None,
        text: str | None,
        thumbInline: str | None,
        fileName: str | None = None,
        show_progress_bar: bool = False,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        context: dict[str, Any] | None = None,
        auto_escape: bool = True
    ) -> dict | None:
        if fileName is None:
            fileName = Utils.format_file("Gif")
        return await self.baseSendFileInline(
            objectGuid=objectGuid,
            file=file,
            text=text,
            messageId=messageId,
            fileName=fileName,
            type="Gif",
            customThumbInline=thumbInline,
            show_progress_bar=show_progress_bar,
            parse_mode=parse_mode,
            context=context,
            auto_escape=auto_escape
        )


    async def sendMusic(
        self,
        objectGuid: str,
        file: str,
        messageId: str | None,
        text: str | None,
        performer: str | None,
        fileName: str | None = None,
        show_progress_bar: bool = False,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        context: dict[str, Any] | None = None,
        auto_escape: bool = True
    ) -> dict | None:
        if fileName is None:
            fileName = Utils.format_file("Music")
        return await self.baseSendFileInline(
            objectGuid=objectGuid,
            file=file,
            text=text,
            messageId=messageId,
            fileName=fileName,
            type="Music",
            performer=performer,
            show_progress_bar=show_progress_bar,
            parse_mode=parse_mode,
            context=context,
            auto_escape=auto_escape
        )


    async def sendVoice(
        self,
        objectGuid: str,
        file: str,
        time: int,
        messageId: str | None = None,
        text: str | None = None,
        fileName: str | None = None,
        show_progress_bar: bool = False,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        context: dict[str, Any] | None = None,
        auto_escape: bool = True
    ) -> dict | None:
        if fileName is None:
            fileName = Utils.format_file("Voice")
        return await self.baseSendFileInline(
            objectGuid=objectGuid,
            file=file,
            text=text,
            messageId=messageId,
            fileName=fileName,
            type="Voice",
            time=time,
            show_progress_bar=show_progress_bar,
            parse_mode=parse_mode,
            context=context,
            auto_escape=auto_escape
        )


    @with_wait("sending")
    async def sendLocation(self, objectGuid:str, latitude:int, longitude:int, messageId:str | None) -> dict:
        return await self.network.request(
            method="sendMessage",
            input={
                "location": {
                    "latitude": latitude,
                    "longitude": longitude
                },
                "object_guid":objectGuid,
                "rnd": Utils.randomRnd(),
                "reply_to_message_id": messageId
            }
        )


    @with_wait("sending")
    async def sendMessageAPICall(self, objectGuid:str, text:str, messageId:str, buttonId:str) -> dict:
        return await self.network.request(
            method="sendMessageAPICall",
            input={
                "text": text,
                "object_guid": objectGuid,
                "message_id": messageId,
                "aux_data": {"button_id": buttonId}
            }
        )


    @with_wait("editing")
    async def editMessage(
        self,
        objectGuid: str,
        text: str,
        messageId: str | None = None,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        context: dict[str, Any] | None = None,
        auto_escape: bool = True
    ) -> dict:
        metadata, _text = await self._prepare_text(text, parse_mode, context, auto_escape)
        data = {
            "object_guid": objectGuid,
            "text": _text,
            "message_id": messageId,
        }
        if metadata != []:
            data["metadata"] = {"meta_data_parts": metadata}
        return await self.network.request("editMessage", data)


    async def actionOnMessageReaction(self, objectGuid:str, messageId:str, reactionId:int |str, action:str) -> dict:
        if type(reactionId) is str:
            reactionId = Utils.reaction_to_id(reactionId)
        return await self.network.request(
            method="actionOnMessageReaction",
            input={
                "action": action, # Add OR Remove
                "object_guid": objectGuid,
                "message_id": messageId,
                "reaction_id": reactionId
            }
        )


    async def setPinMessage(self, objectGuid:str, messageId:str, action:str) -> dict:
        return await self.network.request(
            method="setPinMessage",
            input={
                "object_guid": objectGuid,
                "message_id": messageId,
                "action": action
            }
        )


    @with_wait("sending")
    async def resendMessage(
        self,
        objectGuid: str | None = None,
        messageId: str | None = None,
        toObjectGuid: str | None = None,
        replyToMessageId: str | None = None,
        text: str | None = None,
        fileInline: dict | None = None,
        parse_mode: Literal["Markdown", "HTML", None] = "Markdown",
        context: dict[str, Any] | None = None,
        auto_escape: bool = True
    ) -> dict:
        messageData = {}
        if not fileInline:
            if objectGuid:
                messageData: dict = await self.getMessagesById(objectGuid=objectGuid, messageIds=[messageId])
            else:
                raise ValueError("You Shoud Write The 'fileInline' or (objectGuid, messageId) Args")

        if not text and not messageData:
            raise ValueError("You Shoud Write The 'text' or (objectGuid, messageId) Args")
        text_: str = text or messageData["messages"][0]["text"]
        metadata, _text = await self._prepare_text(text_, parse_mode, context, auto_escape)
        input = {
            "is_mute": False,
            "object_guid": toObjectGuid,
            "rnd": Utils.randomRnd(),
            "reply_to_message_id": replyToMessageId,
            "text": _text
        }

        fileInline_:dict = fileInline or messageData["messages"][0]["file_inline"]
        if fileInline_:
            input["file_inline"] = fileInline_

        if not fileInline_:
            location:dict = messageData["messages"][0].get("location")
            if location:
                input["location"] = location
                del input["location"]["map_view"]
                del input["text"]

            contact:dict = messageData["messages"][0].get("message_contact")
            if contact:
                input["message_contact"] = contact
                del input["text"]

            sticker:dict = messageData["messages"][0].get("sticker")
            if sticker:
                input["sticker"] = sticker
                del input["text"]

            if messageData["messages"][0].get("metadata"):
                input["metadata"] = {"meta_data_parts": messageData["messages"][0]["metadata"]}

        elif metadata != []:
            input["metadata"] = {"meta_data_parts": metadata}

        return await self.network.request(method="sendMessage", input=input)


    @with_wait("forwarding")
    async def forwardMessages(self, objectGuid:str, messageIds:list, toObjectGuid:str) -> dict:
        return await self.network.request(
            method="forwardMessages",
            input={
                "from_object_guid": objectGuid,
                "message_ids": messageIds,
                "to_object_guid": toObjectGuid,
                "rnd": Utils.randomRnd(),
            }
        )


    @with_wait("deleting")
    async def deleteMessages(self, objectGuid:str, messageIds:list, deleteForAll: bool = True) -> dict:
        return await self.network.request(
            method="deleteMessages",
            input={
                "object_guid": objectGuid,
                "message_ids": messageIds,
                "type": "Global" if deleteForAll else "Local"
            }
        )


    async def autoDelete(self, objectGuid: str, messageId: str, time: int, deleteForAll: bool = True):
        await asyncio.sleep(time)
        return await self.deleteMessages(
            objectGuid=objectGuid,
            messageIds=[messageId],
            deleteForAll=deleteForAll
        )


    @cached(cache_key_func=lambda self, objectGuid, middleMessageId: f"getMessagesInterval:{objectGuid}:{middleMessageId}")
    async def getMessagesInterval(
        self,
        objectGuid: str,
        middleMessageId: str
    ) -> dict:
        return await self.network.request(
            method="getMessagesInterval",
            input={
                "object_guid": objectGuid,
                "middle_message_id": middleMessageId
            }
        )


    @cached(cache_key_func=lambda self, objectGuid, maxId, filterType, limit: f"getMessages:{objectGuid}:{maxId}:{filterType}:{limit}")
    async def getMessages(
        self,
        objectGuid: str,
        maxId: str | None,
        filterType: str | None,
        limit: int
    ) -> dict:
        input = {
            "object_guid": objectGuid,
            "sort": "FromMax",
            "max_id": maxId,
            "limit": limit
        }

        if filterType: input["filter_type"] = filterType

        return await self.network.request(
            method="getMessages",
            input=input
        )


    @cached(cache_key_func=lambda self, objectGuid: f"getMessagesUpdates:{objectGuid}")
    async def getMessagesUpdates(
        self,
        objectGuid: str
    ) -> dict:
        return await self.network.request(
            method="getMessagesUpdates",
            input={
                "object_guid": objectGuid,
                "state": Utils.getState(),
            }
        )


    @cached(cache_key_func=lambda self, objectGuid, messageIds: f"getMessagesById:{objectGuid}:{messageIds}")
    async def getMessagesById(
        self,
        objectGuid: str,
        messageIds: list | str
    ) -> dict:
        if type(messageIds) is str:
            messageIds = [messageIds]
        return await self.network.request(
            method="getMessagesByID",
            input={
                "object_guid": objectGuid,
                "message_ids": messageIds,
            }
        )


    @cached(cache_key_func=lambda self, objectGuid, messageId: f"getMessageShareUrl:{objectGuid}:{messageId}")
    async def getMessageShareUrl(
        self,
        objectGuid: str,
        messageId: str
    ) -> dict:
        return await self.network.request(
            method="getMessageShareUrl",
            input={
                "object_guid": objectGuid,
                "message_id": messageId,
            }
        )


    async def clickMessageUrl(self, objectGuid:str, messageId:str, linkUrl:str) -> dict:
        return await self.network.request(
            method="clickMessageUrl",
            input={
                "object_guid": objectGuid,
                "message_id": messageId,
                "link_url": linkUrl
            }
        )


    @cached(cache_key_func=lambda self, searchText: f"searchGlobalMessages:{searchText}")
    async def searchGlobalMessages(
        self,
        searchText: str
    ) -> dict:
        return await self.network.request(
            method="search_text",
            input={
                "search_text": searchText,
                "type": "Text",
            }
        )


    async def requestSendFile(self, fileName:str, mime:str, size:int) -> dict:
        return await self.network.request(
            method="requestSendFile",
            input={
                "file_name": fileName,
                "mime": mime,
                "size": str(size)
            }
        )

    # Contact methods


    @with_wait("sending")
    async def sendContact(self, objectGuid:str, firstName:str, lastName:str, phoneNumber:str, userGuid:str, messageId:str | None) -> dict:
        return await self.network.request(
            method="sendMessage",
            input={
                "message_contact":{
                    "first_name": firstName,
                    "last_name": lastName or "",
                    "phone_number": phoneNumber,
                    "user_guid": userGuid
                },
                "object_guid":objectGuid,
                "rnd": Utils.randomRnd(),
                "reply_to_message_id": messageId
            }
        )


    @cached(cache_key_func=lambda self, startId: f"getContacts:{startId}")
    async def getContacts(
        self,
        startId: str | None
    ) -> dict:
        return await self.network.request(method="getContacts", input={"start_id": startId})


    @cached(cache_key_func=lambda self, userGuids: f"getContactsLastOnline:{userGuids}")
    async def getContactsLastOnline(
        self,
        userGuids: list
    ) -> dict:
        return await self.network.request(
            method="getContactsLastOnline",
            input={
                "user_guids": userGuids
            }
        )


    async def addAddressBook(self, phone:str, firstName:str, lastName:str) -> dict:
        return await self.network.request(
            method="addAddressBook",
            input={
                "phone": f"98{Utils.phone_number_parse(phone)}",
                "first_name": firstName,
                "last_name": lastName
            }
        )


    async def deleteContact(self, objectGuid:str) -> dict:
        return await self.network.request(method="deleteContact", input={"user_guid": objectGuid})


    @cached
    async def getContactsUpdates(self) -> dict:
        return await self.network.request(
            method="getContactsUpdates",
            input={
                "state": Utils.getState()
            }
        )

    # Sticker methods


    @with_wait("sending")
    async def sendSticker(self, objectGuid:str, emoji:str | None, messageId:str | None, stickerData:str | None) -> dict:
        data = {
            "sticker": (stickerData or choice((await self.getStickersByEmoji(emoji))["stickers"])) if emoji else None,
            "object_guid": objectGuid,
            "rnd": Utils.randomRnd(),
            "reply_to_message_id": messageId,
        }

        return await self.network.request("sendMessage", data)


    @cached
    async def getMyStickerSets(self) -> dict:
        return await self.network.request(method="getMyStickerSets")


    @cached(cache_key_func=lambda self, startId: f"getTrendStickerSets:{startId}")
    async def getTrendStickerSets(
        self,
        startId: str | None
    ) -> dict:
        return await self.network.request(method="getTrendStickerSets", input={"start_id": startId})


    @cached(cache_key_func=lambda self, searchText, startId: f"searchStickers:{searchText}:{startId}")
    async def searchStickers(
        self,
        searchText: str,
        startId: str | None
    ) -> dict:
        return await self.network.request(
            method="searchStickers",
            input={
                "search_text": searchText,
                "start_id": startId
            }
        )


    async def actionOnStickerSet(self, stickerSetId:str, action:str) -> dict:
        return await self.network.request(
            method="actionOnStickerSet",
            input={
                "sticker_set_id": stickerSetId,
                "action": action
            }
        )


    @cached(cache_key_func=lambda self, emoji: f"getStickersByEmoji:{emoji}")
    async def getStickersByEmoji(
        self,
        emoji: str
    ) -> dict:
        return await self.network.request(
            method="getStickersByEmoji",
            input={
                "emoji_character": emoji,
                "suggest_by": "All"
            }
        )


    @cached(cache_key_func=lambda self, stickerSetIds: f"getStickersBySetIDs:{stickerSetIds}")
    async def getStickersBySetIDs(
        self,
        stickerSetIds: list
    ) -> dict:
        return await self.network.request(
            method="getStickersBySetIDs",
            input={
                "sticker_set_ids": stickerSetIds
            }
        )

    # Gif methods


    @cached
    async def getMyGifSet(self) -> dict:
        return await self.network.request(method="getMyGifSet")


    async def addToMyGifSet(self, objectGuid:str, messageId:str) -> dict:
        return await self.network.request(
            method="addToMyGifSet",
            input={
                "message_id": messageId,
                "object_guid": objectGuid
            }
        )


    async def removeFromMyGifSet(self, fileId:str) -> dict:
        return await self.network.request(method="removeFromMyGifSet", input={"file_id": fileId})

    # Poll methods


    @with_wait("sending")
    async def sendPoll(
        self,
        objectGuid: str,
        question: str,
        options: list,
        allowsMultipleResponses: bool = True,
        isAnonymous: bool = False,
        type: Literal["Quiz", "Regular"] = "Regular",
        messageId: str | None = None,
        correctOptionIndex: int | None = None,
        hint: str | None = None
    ) -> dict:
        if not type in ['Quiz', 'Regular']:
            raise ValueError('type poll invalid ! type shoud is "Quiz" or "Regular".')
        if len(options) > 2:
            raise IndexError("Len for options is low ! Minimum for options is 2.")
        data = {
            'object_guid': objectGuid,
            'question': question,
            'options': options,
            'allows_multiple_answers': allowsMultipleResponses,
            'is_anonymous': isAnonymous,
            'reply_to_message_id': messageId,
            'type': type,
            'rnd': Utils.randomRnd(),
        }
        if type == 'Quiz':
            data['correct_option_index'] = correctOptionIndex
            data['explanation'] =  hint
        return await self.network.request(
            method="createPoll",
            input=data
        )


    async def votePoll(self, pollId:str, selectionIndex:int) -> dict:
        return await self.network.request(
            method="votePoll",
            input={
                "poll_id": pollId,
                "selection_index": selectionIndex
            }
        )


    @cached(cache_key_func=lambda self, pollId: f"getPollStatus:{pollId}")
    async def getPollStatus(
        self,
        pollId: str
    ) -> dict:
        return await self.network.request(method="getPollStatus", input={"poll_id": pollId})


    @cached(cache_key_func=lambda self, pollId, selectionIndex, startId: f"getPollOptionVoters:{pollId}:{selectionIndex}:{startId}")
    async def getPollOptionVoters(
        self,
        pollId: str,
        selectionIndex: int,
        startId: str | None = None
    ) -> dict:
        return await self.network.request(
            method="getPollOptionVoters",
            input={
                "poll_id": pollId,
                "selection_index": selectionIndex,
                "start_id": startId
            }
        )

    # Live methods


    @with_wait("sending")
    async def sendLive(self, objectGuid:str, thumbInline:bytes |str) -> dict:
        if isinstance(thumbInline,bytes):
            by = thumbInline
        elif isinstance(thumbInline,str):
            if Utils.checkLink(thumbInline):
                by = (await self.network._client.request("GET", thumbInline)).content # pyright: ignore[reportOptionalMemberAccess]
                if not isinstance(by, bytes):
                    raise ValueError("Error !")
            else:
                with open(thumbInline,"rb") as file:
                    by = file.read()
        else:
            raise ValueError("thumbInline is byte or str !")
        return await self.network.request(
            method="sendLive",
            input={
                "thumb_inline": Utils.getImageThumbnail(by),
                "device_type": "Software",
                "object_guid": objectGuid,
                "rnd": Utils.randomRnd()
            }
        )


    async def addLiveComment(self, accessToken:str, liveId:str, text:str) -> dict:
        return await self.network.request(
            method="addLiveComment",
            input={
                "access_token": accessToken,
                "live_id": liveId,
                "text": text
            }
        )


    async def getLiveStatus(self, accessToken:str, liveId:str) -> dict:
        return await self.network.request(
            method="getLiveStatus",
            input={
                "access_token": accessToken,
                "live_id": liveId,
                "type": "LiveViewer"
            }
        )


    @cached(cache_key_func=lambda self, accessToken, liveId: f"getLiveComments:{accessToken}:{liveId}")
    async def getLiveComments(
        self,
        accessToken: str,
        liveId: str
    ) -> dict:
        return await self.network.request(
            method="getLiveComments",
            input={
                "access_token": accessToken,
                "live_id": liveId,
            }
        )


    @cached(cache_key_func=lambda self, accessToken, liveId: f"getLivePlayUrl:{accessToken}:{liveId}")
    async def getLivePlayUrl(
        self,
        accessToken: str,
        liveId: str
    ) -> dict:
        return await self.network.request(
            method="getLivePlayUrl",
            input={
                "access_token": accessToken,
                "live_id": liveId
            }
        )

    # Call methods


    async def requestCall(self, objectGuid:str, callType:str) -> dict:
        return await self.network.request(
            method="requestCall",
            input={
                "call_type": callType,
                "library_versions": ["2.7.7","2.4.4"],
                "max_layer": 92,
                "min_layer": 65,
                "sip_version": 1,
                "support_call_out": True,
                "user_guid": objectGuid
            }
        )


    async def discardCall(self, callId:str, duration:int, reason:str) -> dict:
        return await self.network.request(
            method="discardCall",
            input={
                "call_id": callId,
                "duration": duration,
                "reason": reason #Missed OR Disconnect
            }
        )

    # Setting methods


    async def setSetting(
        self,
        showMyLastOnline:bool | None,
        showMyPhoneNumber:bool | None,
        showMyProfilePhoto:bool | None,
        linkForwardMessage:bool | None,
        canJoinChatBy:bool | None
    ) -> dict:

        input:dict = {
            "settings": {},
            "update_parameters": []
        }

        if not showMyLastOnline is None:
            input["settings"]["show_my_last_online"] = "Everybody" if showMyLastOnline else "Nobody"
            input["update_parameters"].append("show_my_last_online")

        if not showMyPhoneNumber is None:
            input["settings"]["show_my_phone_number"] = "Everybody" if showMyPhoneNumber else "Nobody"
            input["update_parameters"].append("show_my_phone_number")

        if not showMyProfilePhoto is None:
            input["settings"]["show_my_profile_photo"] = "Everybody" if showMyProfilePhoto else "MyContacts"
            input["update_parameters"].append("show_my_profile_photo")

        if not linkForwardMessage is None:
            input["settings"]["link_forward_message"] = "Everybody" if linkForwardMessage else "Nobody"
            input["update_parameters"].append("link_forward_message")

        if not canJoinChatBy is None:
            input["settings"]["can_join_chat_by"] = "Everybody" if canJoinChatBy else "MyContacts"
            input["update_parameters"].append("can_join_chat_by")

        return await self.network.request(
            method="setSetting",
            input=input
        )


    async def addFolder(
        self,
        folderName:str,
        folderId:str,
        excludeChatIds:list,
        excludeChatTypes:list,
        includeChatIds:list,
        includeChatTypes:list
    ) -> dict:

        return await self.network.request(
            method="addFolder",
            input={
                "exclude_object_guids": excludeChatIds,
                "include_object_guids": excludeChatTypes,
                "exclude_chat_types": includeChatIds,
                "include_chat_types": includeChatTypes,
                "folder_id": folderId,
                "is_add_to_top": True,
                "name": folderName
            }
        )


    @cached(cache_key_func=lambda self, lastState: f"getFolders:{lastState}")
    async def getFolders(
        self,
        lastState: str | None
    ) -> dict:
        return await self.network.request(method="getFolders", input={"last_state": lastState})


    @cached
    async def getSuggestedFolders(self) -> dict:
        return await self.network.request(method="getSuggestedFolders")


    async def deleteFolder(self, folderId:str) -> dict:
        return await self.network.request(method="deleteFolder", input={"folder_id": folderId})


    async def updateProfile(self, firstName:str | None, lastname:str | None, bio:str | None, username:str | None) -> dict:
        input:dict = {
            "first_name": firstName,
            "last_name": lastname,
            "bio": bio,
            "updated_parameters": []
        }

        if firstName:input["updated_parameters"].append("first_name")
        if lastname: input["updated_parameters"].append("last_name")
        if bio: input["updated_parameters"].append("bio")

        if username:
            response:dict = await self.network.request(method="updateUsername", input={"username": username})
            if not input["updated_parameters"]:
                return response

        return await self.network.request(
            method="updateProfile",
            input=input
        )


    @cached
    async def getMySessions(self) -> dict:
        return await self.network.request(method="getMySessions")


    async def terminateSession(self, sessionKey:str) -> dict:
        return await self.network.request(method="terminateSession", input={"session_key": sessionKey})


    async def terminateOtherSessions(self):
            return await self.network.request("terminateOtherSessions")


    async def checkTwoStepPasscode(self, password:str) -> dict:
        return await self.network.request(method="checkTwoStepPasscode", input={"password": password})


    async def setupTwoStepVerification(self, password:str, hint:str, recoveryEmail:str) -> dict:
        return await self.network.request(
            method="setupTwoStepVerification",
            input={
                "password": password,
                "hint": hint,
                "recovery_email": recoveryEmail
            }
        )


    async def requestRecoveryEmail(self, password:str, recoveryEmail:str) -> dict:
        return await self.network.request(
            method="requestRecoveryEmail",
            input={
                "password": password,
                "recovery_email": recoveryEmail
            }
        )


    async def verifyRecoveryEmail(self, password:str, code:str) -> dict:
        return await self.network.request(
            method="verifyRecoveryEmail",
            input={
                "password": password,
                "code": code
            }
        )


    async def turnOffTwoStep(self, password:str) -> dict:
        return await self.network.request(method="turnOffTwoStep", input={"password": password})


    async def changePassword(self, password:str, newPassword:str, newHint:str) -> dict:
        return await self.network.request(
            method="changePassword",
            input={
                "password": password,
                "new_password": newPassword,
                "new_hint": newHint
            }
        )


    @cached
    async def getTwoPasscodeStatus(self) -> dict:
        return await self.network.request(method="getTwoPasscodeStatus")


    @cached
    async def getPrivacySetting(self) -> dict:
        return await self.network.request(method="getPrivacySetting")


    @cached(cache_key_func=lambda self, startId: f"getBlockedUsers:{startId}")
    async def getBlockedUsers(self, startId:str | None) -> dict:
        return await self.network.request(method="getBlockedUsers", input={"start_id": startId})

    # Other methods


    @cached
    async def getMe(self) -> dict:
        data = await self.network.request(method="getUserInfo")
        data.update(self.sessionData)
        return data


    async def transcribeVoice(self, objectGuid:str, messageId:str) -> dict:
        response = await self.network.request(
            method="transcribeVoice",
            input={
                "object_guid": objectGuid,
                "message_id": messageId
            }
        )

        if response["status"] != "OK":
            return response

        while True:
            sleep(0.5)
            result = await self.network.request(
                method="getTranscription",
                input={
                    "message_id": messageId,
                    "transcription_id": response["transcription_id"]
                }
            )

            if result["status"] != "OK":
                continue

            return result


    async def resetContacts(self) -> dict:
        return await self.network.request("resetContacts")


    @cached
    async def getTime(self) -> dict:
        return await self.network.request("getTime")


    @cached(cache_key_func=lambda self, objectGuids: f"getAbsObjects:{objectGuids}")
    async def getAbsObjects(self, objectGuids:list) -> dict:
        return await self.network.request(method="getAbsObjects", input={"object_guids": objectGuids})


    @cached(cache_key_func=lambda self, url: f"getLinkFromAppUrl:{url}")
    async def getLinkFromAppUrl(
        self,
        url: str
    ) -> dict:
        return await self.network.request(method="getLinkFromAppUrl", input={"app_url": url})


    @cached(cache_key_func=lambda self, searchText, filters: f"searchGlobalObjects:{searchText}:{filters}")
    async def searchGlobalObjects(
        self,
        searchText: str,
        filters: list | None
    ) -> dict:
        input: dict= {"search_text": searchText}
        if filters:
            input["filter_types"] = filters

        return await self.network.request(method="searchGlobalObjects", input=input)


    @cached(cache_key_func=lambda self, objectGuid, userGuid: f"checkJoin:{objectGuid}:{userGuid}")
    async def checkJoin(self, objectGuid:str, userGuid:str) -> bool | None:
        userUsername: str = (await self.getChatInfo(userGuid))["user"].get("username")

        if userGuid in (await self.getChatAllMembers(objectGuid=objectGuid, searchText=userUsername, startId=None, justGetGuids=True)):
            return True

        if userUsername:
            return False

        return None


    @cached(cache_key_func=lambda self, objectGuid: f"getProfileLinkItems:{objectGuid}")
    async def getProfileLinkItems(self, objectGuid:str) -> dict:
        return await self.network.request(method="getProfileLinkItems", input={"object_guid": objectGuid})


    @cached(cache_key_func=lambda self, objectGuid, messageId, fileInline: f"getDownloadLink:{objectGuid}:{messageId}:{fileInline}")
    async def getDownloadLink(
        self,
        objectGuid: str,
        messageId: str | None,
        fileInline: dict | None
    ) -> str | None:
        if not fileInline:
            msg = await self.getMessagesById(objectGuid=objectGuid, messageIds=[messageId])
            fileInline = msg["messages"][0]["file_inline"]
        if fileInline:
            return f'https://messenger{fileInline["dc_id"]}.iranlms.ir/InternFile.ashx?id={fileInline["file_id"]}&ach={fileInline["access_hash_rec"]}'


    async def download(self,save:bool, objectGuid: str, messageId:str | None = None, saveAs:str | None = None, fileInline:dict | None = None) -> dict | None:
        if fileInline is None:
            msg = await self.getMessagesById(objectGuid=objectGuid, messageIds=[messageId])
            fileInline = msg["messages"][0]["file_inline"]
        if not fileInline is None:
            downloading = await self.network.download(
                accessHashRec=fileInline["access_hash_rec"],
                fileId=fileInline["file_id"],
                dcId=fileInline["dc_id"],
                size=fileInline["size"],
                fileName=fileInline["file_name"]
            )

            if downloading:
                downloadedData:bytes = downloading

                if save or saveAs:
                    with open(saveAs or fileInline["file_name"], "wb") as file:
                        file.write(downloadedData)

                fileInline["file"] = downloadedData

                return fileInline


    async def request(
        self,
        method: str,
        input: dict = {},
        tmpSession: bool = False,
        attempt: int = 0,
        maxAttempt: int = 2
    ) -> dict:
        return await self.network.request(method=method,input=input,tmpSession=tmpSession,attempt=attempt,maxAttempt=maxAttempt)


    async def playVoice(self, objectGuid:str, file: str) -> None:
        try:
            from aiortc import RTCPeerConnection, RTCSessionDescription
            from aiortc.contrib.media import MediaPlayer
            voiceChatId: str = ((await self.getChatInfo(objectGuid))["chat"])["group_voice_chat_id"]

            if not voiceChatId:
                voiceChatId:str = (await self.createChatVoiceChat(objectGuid=objectGuid))["group_voice_chat_update"]["voice_chat_id"]

            rtcConnection = RTCPeerConnection()
            player: MediaPlayer = MediaPlayer(file)

            if player.audio is None:
                print(f"Error: Cannot load audio from file: {file}")
                await rtcConnection.close()
                return

            rtcConnection.addTrack(player.audio)
            spdOffer = await rtcConnection.createOffer()
            await rtcConnection.setLocalDescription(spdOffer)

            answerSdp = (await self.joinVoiceChat(
                objectGuid=objectGuid,
                myGuid=self.sessionData["user"]["user_guid"],
                voiceChatId=voiceChatId,
                sdp_offer_data=spdOffer.sdp
            ))["sdp_answer_data"]

            await self.setChatVoiceChatState(
                objectGuid=objectGuid,
                voideChatId=voiceChatId,
                activity="Unmute",
                participantObjectGuid=self.sessionData["user"]["user_guid"]
            )

            remoteDescription = RTCSessionDescription(answerSdp, "answer")
            await rtcConnection.setRemoteDescription(remoteDescription)

            def onEnded():
                asyncio.create_task(rtcConnection.close())

            player.audio.on("ended", onEnded)

            async def keepAlive():
                while rtcConnection.connectionState != "closed":
                    try:
                        sending_code = await self.sendChatVoiceChatActivity(
                            objectGuid=objectGuid,
                            voideChatId=voiceChatId,
                            activity="Speaking",
                            participantObjectGuid=self.sessionData["user"]["user_guid"]
                        )
                        if sending_code["status"] != "OK":
                            print({"status": sending_code["status"], "method": "sendChatVoiceChatActivity"})
                            break

                        if (await self.getChatVoiceChatUpdates(
                            objectGuid=objectGuid,
                            voideChatId=voiceChatId
                        ))["status"] != "OK":
                            print({"status": sending_code["status"], "method": "getChatVoiceChatUpdates"})
                            break

                        await asyncio.sleep(8)
                    except (InvalidAuth, InvalidInput) as e:
                        print(e)
                        break
                    except Exception as e:
                        print(e)
                        continue

            keepalive_task = asyncio.create_task(keepAlive())

            try:
                while rtcConnection.connectionState != "closed":
                    await asyncio.sleep(1)
            finally:
                keepalive_task.cancel()
                await rtcConnection.close()

            asyncio.create_task(rtcConnection.close())

        except ImportError:
            raise ImportError("The aiortc library is not installed! for install: 'pip install aiortc' or 'pip install fastrub[pyrubi-aiortc]'")

    def on_ready(self):
        """when client read for sending requests and no has problem for sending requests / زمانی که کلاینت آماده برای ارسال درخواست ها شده و مشکلی برای ارسال درخواست ها ندارد"""
        def decorator(func):
            self._on_ready_handlers.append(func)
            return func
        return decorator

    def on_start(self):
        """when client read for sending requests / زمانی که کلاینت آماده برای ارسال درخواست ها شد"""
        def decorator(func):
            self._on_start_handlers.append(func)
            return func
        return decorator

    def on_run(self):
        """when start getting messages / زمانی که گرفتن پیام ها شروع می شود"""
        def decorator(func):
            self._on_run_handlers.append(func)
            return func
        return decorator

    def on_error(
        self,
        error_detail: Literal["full", "message", "type"] = "message"
    ):
        """Manage errors in handlers / مدیریت خطا های پیش بینی نشده در هندلر ها"""
        def decorator(func):
            self._on_error_handlers.append(
                {
                    "handler": func,
                    "error_detail": error_detail
                }
            )
            return func
        return decorator

    def on_live(self):
        """when socket , connected / زمانی که سوکت وصل شود"""
        def decorator(func):
            self._on_live_handlers.append(func)
            return func
        return decorator

    # def on_shutdown( # When add method close
    #     self
    # ):
    #     """دکوراتور برای زمانی که ربات خاموش می‌شود (هنگام close)."""
    #     def decorator(func: Callable):
    #         self._on_shutdown_handlers.append(func)
    #         return func
    #     return decorator

    # on_close = on_shutdown

    def before_run(self):
        """دکوراتور برای ثبت handler قبل از اجرای run"""
        def decorator(func):
            self._before_run_handlers.append(func)
            return func
        return decorator

    def after_run(self):
        """دکوراتور برای ثبت handler بعد از اجرای run"""
        def decorator(func):
            self._after_run_handlers.append(func)
            return func
        return decorator


    async def _process_on_ready(self):
        if self._on_ready_handlers:
            try:
                me = await self.getMe()
                # self.logger.info("دکوراتور های on ready با موفقیت در حال اجرا هستند")
                # self.logger.info(f"bot info :\n{me}")
                is_ok = True
            except:
                is_ok = False
            if is_ok:
                for handler in self._on_ready_handlers:
                    try:
                        await handler()
                    except Exception as e:
                        # self.logger.error(f"on_ready error : {e}")
                        raise e
            else:
                raise httpx.NetworkError("Can't Cannecting To Server BotAPI for GetMe !")

    async def _process_on_start(self):
        for handler in self._on_start_handlers:
            try:
                await handler()
            except Exception as e:
                # self.logger.error(f"on_start error : {e}")
                raise e

    async def _process_on_error(
        self,
        e: Exception,
        update: Message | None = None
    ):
        if self._on_error_handlers:
            for handler_info in self._on_error_handlers:
                try:
                    error_handler = handler_info["handler"]
                    type_error = handler_info["error_detail"]
                    if type_error == "full":
                        error = format_exc()
                    elif type_error == "message":
                        error = e
                    elif type_error == "type":
                        error = type(e).__name__
                    else:
                        error = "error invalid input"
                        # self.logger.warning(error)
                        print(error)
                    await error_handler(error, update)
                except Exception as exc:
                    # self.logger.error(f"Error in on_error handler : {exc}")
                    print(f"Error in on_error handler : {exc}")
        else:
            # self.logger.error(f"Handler error : {e}", exc_info=True)
            print(f"Handler error : {e}")

    async def _process_on_live(self):
        for handler in self._on_live_handlers:
            try:
                await handler()
            except Exception as e:
                # self.logger.error(f"on_live error : {e}")
                raise e

    async def _process_after_run(self):
        for handler in self._after_run_handlers:
            try:
                result = handler()
                if asyncio.iscoroutine(result):
                    await result
            except Exception as e:
                # self.logger.error(f"Error in after_run handler: {e}")
                raise e

    async def _process_before_run(self):
        for handler in self._before_run_handlers:
            try:
                result = handler()
                if asyncio.iscoroutine(result):
                    await result
            except Exception as e:
                # self.logger.error(f"Error in before_run handler: {e}")
                raise e

    # async def _process_on_shutdown(self): # When add method close
    #     for handler in self._on_shutdown_handlers:
    #         try:
    #             await handler()
    #         except Exception as e:
    #             # self.logger.error(f"on_shutdown error : {e}")
    #             raise e

    def add_handler(self, func, filters: list[Filter] | list[str] | Filter | None = None) -> None:
        self.socket.add_handler(
            func=func,
            filters=filters
        )
        return func

    async def run(self) -> None:
        await self.socket.connect()
