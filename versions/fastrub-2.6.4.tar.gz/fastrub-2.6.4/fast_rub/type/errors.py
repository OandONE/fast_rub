class TokenInvalid(Exception):
    pass

class PollInvalid(Exception):
    pass

class ServerRubikaError(Exception):
    pass

class CreateSessionError(Exception):
    pass