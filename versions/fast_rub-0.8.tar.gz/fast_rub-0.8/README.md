# fast rub

This Python library is for Rubika bots and is currently being updated.

## fast rub

- 1 fast
- 2 simple syntax
- 3 Small size of the library

## install :

```bash
pip install --no-deps https://parssource.ir/fast_rub/fast_rub-0.8.tar.gz