class TokenInvalid(Exception):
    pass

class PollInvalid(Exception):
    pass