from .client import Client

__version__ = "3.6.0-fork"
__author__ = "seyyed mohamad hosein moosavi raja"
__original_author__ = "Ali Ganji zadeh"