class FastRubError(Exception):
    pass