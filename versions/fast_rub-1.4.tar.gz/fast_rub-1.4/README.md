# fast rub

This Python library is for Rubika bots and is currently being updated.

## fast rub

- 1 fast
- 2 simple syntax
- 3 Small size of the library

## install :

```bash
pip install https://ParsSource.ir/fast_rub/fast_rub-1.4.tar.gz```