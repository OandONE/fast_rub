<img src="https://fast-rub.ParsSource.ir/icon.jpg">

# fast rub

This Python library is for Rubika bots and is currently being updated.

## fast rub

- 1 fast
- 2 simple syntax
- 3 Small size of the library

## install :

```bash
pip install https://ParsSource.ir/fast_rub/fast_rub-2.2.tar.gz
```

[Documents](https://fast-rub.ParsSource.ir/index.html)

قسمت pyrubi این کتابخانه فورک شده کتابخانه پایروبی است
گیت هاب اصلی پایروبی : https://github.com/AliGanji1/pyrubi